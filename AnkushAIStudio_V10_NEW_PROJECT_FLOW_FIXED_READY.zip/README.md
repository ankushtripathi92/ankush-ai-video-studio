# Ankush AI Video Studio — V10 New Project Flow

V10 is based on the verified V7 foundation and adds the corrected New Project flow plus the Real News Presenter foundation.

## V10 additions
- My Projects library on the Home screen
- Create, Open/Edit, Duplicate and Delete projects
- Automatic local saving while editing
- Manual Save Project buttons
- Project data survives Back/app interruption
- 16:9 / 9:16 selection is visible inside Presenter Setup and is stored with the project
- Shared project library for all six studios
- Editorial Explainer and Horror Story Studio also participate in the project library
- No paid AI API is called automatically

## Six studios
1. Chitrakoot News
2. Vaidik & Tantrik Gyan
3. Buycryptohub
4. Comedy Conversation
5. Editorial Explainer
6. Horror Story Studio

## Build
The repository workflow uses `AnkushAIStudio_V10_NEW_PROJECT_FLOW_FIXED.zip` and builds a debug APK with Java 17, Android SDK 35 and Gradle 8.9.

This is a foundation build. Real AI voice/avatar/lip-sync/video rendering providers can be connected later through the planned adapter layer.

Navigation behavior: Android Back from a Studio sub-page returns to the Studio menu instead of the app Home; Back from the Studio menu returns to Home.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "com.ankush.aivideostudio"; compileSdk = 35
    defaultConfig { applicationId = "com.ankush.aivideostudio"; minSdk = 23; targetSdk = 35; versionCode = 4; versionName = "4.0" }
}

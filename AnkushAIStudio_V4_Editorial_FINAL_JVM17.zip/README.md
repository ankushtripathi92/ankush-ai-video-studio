# Ankush AI Video Studio — V4 Editorial Explainer

Android foundation project for:
- Chitrakoot News
- Vaidik & Tantrik Gyan
- Buycryptohub
- Comedy Conversation
- Editorial Explainer / Motion Documentary

## Important JVM fix
This V4 build is configured consistently for Java 17 and Kotlin JVM 17:
- compileOptions sourceCompatibility = JavaVersion.VERSION_17
- compileOptions targetCompatibility = JavaVersion.VERSION_17
- kotlinOptions jvmTarget = "17"
- kotlin { jvmToolchain(17) }

This fixes the GitHub Actions error:
`Inconsistent JVM-target compatibility detected ... Java 1.8 and Kotlin 17`.

No paid AI provider is called automatically by this foundation project.

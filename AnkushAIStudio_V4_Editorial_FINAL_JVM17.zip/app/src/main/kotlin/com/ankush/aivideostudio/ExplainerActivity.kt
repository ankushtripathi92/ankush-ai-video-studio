package com.ankush.aivideostudio

import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ExplainerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(0xFF080808.toInt())
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "🎞️ EDITORIAL EXPLAINER"
            textSize = 25f
            setTextColor(0xFFD4AF37.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Story → Scenes → Visuals → Motion → Final Video"
            textSize = 15f
            setTextColor(0xFFEAEAEA.toInt())
            setPadding(0, 8, 0, 20)
        })

        val script = EditText(this).apply {
            hint = "अपनी कहानी / स्क्रिप्ट यहाँ लिखें…"
            minLines = 8
            gravity = 48
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
        }
        root.addView(script, lp())

        root.addView(label("INPUT MODE"))
        val inputMode = Spinner(this)
        inputMode.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Script", "Recorded Voice (future AI transcription)", "Script + Recorded Voice")
        )
        root.addView(inputMode, lp())

        root.addView(label("VISUAL STYLE"))
        val style = Spinner(this)
        style.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf(
                "Editorial Documentary",
                "Paper Collage",
                "2D Illustrated",
                "Historical Archive",
                "Cinematic Story",
                "Map + Timeline",
                "Infographic"
            )
        )
        root.addView(style, lp())

        val checks = listOf(
            "Auto scene / beat detection",
            "Auto image / illustration matching",
            "Auto map & timeline when relevant",
            "Auto captions / key words",
            "Auto motion / pan / zoom",
            "Auto background music & SFX"
        )
        checks.forEach { text ->
            root.addView(CheckBox(this).apply {
                this.text = text
                isChecked = true
                setTextColor(0xFFEAEAEA.toInt())
            })
        }

        root.addView(label("FORMAT"))
        val format = Spinner(this)
        format.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("16:9", "9:16")
        )
        root.addView(format, lp())

        root.addView(label("VISUAL DENSITY"))
        val density = Spinner(this)
        density.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Balanced", "Low", "High")
        )
        root.addView(density, lp())

        root.addView(Button(this).apply {
            text = "🧩 BUILD AUTO SCENE PLAN"
            setOnClickListener {
                Toast.makeText(
                    this@ExplainerActivity,
                    "Scene plan तैयार करने के लिए स्क्रिप्ट चाहिए।",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
        root.addView(Button(this).apply {
            text = "👁 PREVIEW SCENE PLAN"
            setOnClickListener {
                Toast.makeText(
                    this@ExplainerActivity,
                    "V4 foundation preview layer तैयार है।",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
        root.addView(Button(this).apply {
            text = "🚀 PREPARE FOR AI GENERATION"
            setOnClickListener {
                Toast.makeText(
                    this@ExplainerActivity,
                    "AI Engine Adapter के लिए project तैयार है। कोई paid API स्वतः call नहीं होगी।",
                    Toast.LENGTH_LONG
                ).show()
            }
        })

        root.addView(TextView(this).apply {
            text = "\nV4 note: AI image/video generation, voice, lip-sync और final rendering को provider/API adapter layer में जोड़ा जाएगा।"
            textSize = 13f
            setTextColor(0xFFAAAAAA.toInt())
        })

        setContentView(scroll)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = "\n$text"
        textSize = 13f
        setTextColor(0xFFD4AF37.toInt())
    }

    private fun lp() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 6, 0, 12) }
}

package com.ankush.aivideostudio

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class StudioActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val studio = intent.getStringExtra("studioName") ?: "STUDIO"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF080808.toInt())
        }

        root.addView(TextView(this).apply {
            text = studio
            textSize = 24f
            setTextColor(0xFFD4AF37.toInt())
        })

        val items = listOf(
            "🎬 FULL PRESENTER",
            "🎙️ INTERVIEW / EXPERT MODE",
            "👤 ANCHOR / CHARACTER LIBRARY",
            "🖼️ PHOTOS / VIDEOS / MEDIA",
            "📝 SCRIPT / VOICE",
            "📐 16:9 / 9:16",
            "▶️ PREVIEW / GENERATE"
        )

        items.forEach { item ->
            root.addView(Button(this).apply {
                text = item
                isAllCaps = false
                setOnClickListener {
                    Toast.makeText(
                        this@StudioActivity,
                        "V4 foundation: AI generation layer अगले चरण में",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }

        setContentView(root)
    }
}

package com.ankush.aivideostudio

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val bg = 0xFF080808.toInt()
    private val gold = 0xFFD4AF37.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            text = "ANKUSH AI VIDEO STUDIO"
            textSize = 25f
            setTextColor(gold)
            setPadding(0, 0, 0, 8)
        })
        root.addView(TextView(this).apply {
            text = "चारों चैनलों + Editorial Explainer के लिए आपका निजी वीडियो स्टूडियो"
            textSize = 15f
            setTextColor(0xFFEAEAEA.toInt())
            setPadding(0, 0, 0, 24)
        })

        val studios = listOf(
            "📰  चित्रकूट न्यूज़\nNews Presenter • Interview • Guest",
            "🔱  वैदिक एवं तांत्रिक ज्ञान\nPresenter • प्रश्न–उत्तर • Podcast",
            "📈  Buycryptohub\nStock • Crypto • Split Screen",
            "😂  Comedy Conversation\nCharacter 1 • Character 2 • Dialogue",
            "🎞️  Editorial Explainer\nAuto Visual Documentary • Story → Scenes → Visuals"
        )

        studios.forEachIndexed { index, label ->
            root.addView(Button(this).apply {
                text = label
                textSize = 15f
                isAllCaps = false
                setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener {
                    if (index == 4) {
                        startActivity(Intent(this@MainActivity, ExplainerActivity::class.java))
                    } else {
                        startActivity(Intent(this@MainActivity, StudioActivity::class.java).apply {
                            putExtra("studioIndex", index)
                            putExtra("studioName", label.substringBefore("\n"))
                        })
                    }
                }
            }, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 0, 0, 14)
            })
        }

        root.addView(TextView(this).apply {
            text = "\nV4 FOUNDATION • Editorial Explainer • AI Engine Adapter Ready"
            textSize = 13f
            setTextColor(0xFFAAAAAA.toInt())
        })

        setContentView(root)
    }
}

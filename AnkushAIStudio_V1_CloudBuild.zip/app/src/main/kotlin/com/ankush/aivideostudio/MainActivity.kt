package com.ankush.aivideostudio

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private val gold = Color.rgb(212, 175, 55)
    private val bg = Color.rgb(10, 10, 10)
    private val card = Color.rgb(25, 25, 25)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(28, 40, 28, 28)
        }

        root.addView(TextView(this).apply {
            text = "ANKUSH AI VIDEO STUDIO"
            textSize = 25f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 8)
        })

        root.addView(TextView(this).apply {
            text = "चारों चैनलों के लिए आपका निजी वीडियो स्टूडियो"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 30)
        })

        addStudio(root, "📰  चित्रकूट न्यूज़", "News Presenter • Interview • Guest", "NEWS")
        addStudio(root, "🔱  वैदिक एवं तांत्रिक ज्ञान", "Presenter • प्रश्न–उत्तर • Podcast", "VEDIC")
        addStudio(root, "📈  Buycryptohub", "Stock • Crypto • Split Screen", "FINANCE")
        addStudio(root, "😂  Comedy Conversation", "Character 1 • Character 2 • Dialogue", "COMEDY")

        root.addView(TextView(this).apply {
            text = "V1 FOUNDATION • AI ENGINE LATER"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 26, 0, 0)
        })

        setContentView(root)
    }

    private fun addStudio(parent: LinearLayout, title: String, subtitle: String, studio: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(24, 22, 24, 22)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                startActivity(Intent(this@MainActivity, StudioActivity::class.java).apply {
                    putExtra("studio", studio)
                })
            }
        }

        box.addView(TextView(this).apply {
            text = title
            textSize = 19f
            setTextColor(Color.WHITE)
        })
        box.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 0)
        })

        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 0, 16)
        parent.addView(box, lp)
    }
}

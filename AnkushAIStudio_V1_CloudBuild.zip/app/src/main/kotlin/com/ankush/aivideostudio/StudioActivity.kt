package com.ankush.aivideostudio

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class StudioActivity : Activity() {

    private val gold = Color.rgb(212, 175, 55)
    private val bg = Color.rgb(10, 10, 10)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val studio = intent.getStringExtra("studio") ?: "NEWS"
        buildStudio(studio)
    }

    private fun buildStudio(studio: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(24, 35, 24, 24)
        }

        val title = when (studio) {
            "NEWS" -> "📰 चित्रकूट न्यूज़ Studio"
            "VEDIC" -> "🔱 वैदिक एवं तांत्रिक ज्ञान Studio"
            "FINANCE" -> "📈 Buycryptohub Studio"
            else -> "😂 Comedy Conversation Studio"
        }

        root.addView(TextView(this).apply {
            text = title
            textSize = 23f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 28)
        })

        when (studio) {
            "NEWS" -> {
                addButton(root, "🎬 Full News Presenter")
                addButton(root, "🎙️ Interview / Expert Mode")
                addButton(root, "👩 Anchor Library")
                addButton(root, "🖼️ Photos / Videos / Screenshots")
                addButton(root, "📝 Script")
                addButton(root, "🎙️ Voice / Voice Clone")
                addButton(root, "📐 16:9 / 9:16")
            }
            "VEDIC" -> {
                addButton(root, "🎬 Full Presenter")
                addButton(root, "🎙️ प्रश्न–उत्तर / Podcast")
                addButton(root, "👩 Female Anchor Library")
                addButton(root, "👤 Ankush Shastri Avatar")
                addButton(root, "📝 Script")
                addButton(root, "🖼️ Background / Media")
                addButton(root, "📐 16:9 / 9:16")
            }
            "FINANCE" -> {
                addButton(root, "🎬 Center Presenter")
                addButton(root, "📊 Split Screen")
                addButton(root, "🖼️ Information Screenshots")
                addButton(root, "🧠 Script → Visual Matching")
                addButton(root, "🎙️ My Voice / Voice Clone")
                addButton(root, "📈 Stock / Crypto Background")
                addButton(root, "📐 16:9 / 9:16")
            }
            else -> {
                addButton(root, "👤 Character 01")
                addButton(root, "👤 Character 02")
                addButton(root, "💬 Dialogue / Script")
                addButton(root, "🎭 Character Style")
                addButton(root, "🎙️ Voice")
                addButton(root, "⏱️ Duration")
                addButton(root, "📐 16:9 / 9:16")
            }
        }

        addButton(root, "▶ Preview / Generate", true)

        setContentView(root)
    }

    private fun addButton(parent: LinearLayout, label: String, primary: Boolean = false) {
        val b = Button(this).apply {
            text = label
            textSize = if (primary) 16f else 14f
            setTextColor(if (primary) Color.BLACK else Color.WHITE)
            setBackgroundColor(if (primary) gold else Color.rgb(35, 35, 35))
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 0, 10)
        parent.addView(b, lp)
    }
}

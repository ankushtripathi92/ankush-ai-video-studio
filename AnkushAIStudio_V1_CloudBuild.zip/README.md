# Ankush AI Video Studio — V1 Foundation

यह Android-first foundation है।

## वर्तमान V1
- चार Studio Home screen पर
- Chitrakoot News
- Vaidik & Tantrik Gyan
- Buycryptohub
- Comedy Conversation
- प्रत्येक Studio का अलग dashboard
- 16:9 / 9:16 workflow placeholders
- Anchor/Character, Script, Voice, Media और Generate placeholders

## अगला चरण
1. Project/Save system
2. Anchor Library
3. Media Library
4. Script editor
5. Voice upload/recording
6. Real AI engine adapter
7. Lip-sync/avatar generation
8. Timeline assembly
9. MP4 rendering
10. APK testing

## महत्वपूर्ण
V1 में वास्तविक AI video generation अभी intentionally connected नहीं है। इससे पहले UI और application architecture test किया जाएगा।


## GitHub Cloud APK Build

This project includes `.github/workflows/build-apk.yml`.
After the project is uploaded to GitHub, the workflow can build a debug APK in GitHub Actions.
The APK is published as a workflow artifact named `AnkushAIStudio-debug-apk`.

This V1 is a UI foundation. Real AI avatar, voice cloning, lip-sync, rendering and external AI providers are not connected yet.

# Ankush AI Video Studio — V6 Premium Functional

V6 keeps the six-studio architecture and restores a real local workflow instead of Toast-only placeholder buttons.

## Studio order
1. Chitrakoot News
2. Vaidik & Tantrik Gyan
3. Buycryptohub
4. Comedy Conversation
5. Editorial Explainer — editorial/documentary workflow
6. Horror Story Studio — last studio

## What was fixed
- Studio menu buttons now open actual workflow screens.
- Presenter, interview, library, media, script/voice, format and preview flows are functional locally.
- Projects can be saved locally with SharedPreferences.
- Phone media and recorded audio can be selected through Android document picker.
- Editorial Explainer builds a local scene plan from a script.
- Horror Studio builds a local scene plan and includes narration pause/resume + character voice workflow settings.
- No automatic financial screenshot selection is implemented.
- No paid AI API is called automatically.
- Java/Kotlin target remains 17.
- Version 6.0.

## AI layer
AI image/video generation, voice cloning, avatar/lip-sync and final rendering remain behind a provider/API adapter. The foundation is deliberately usable without paid API calls.

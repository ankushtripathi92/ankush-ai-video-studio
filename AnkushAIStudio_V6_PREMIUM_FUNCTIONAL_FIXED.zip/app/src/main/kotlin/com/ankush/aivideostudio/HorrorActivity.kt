package com.ankush.aivideostudio

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class HorrorActivity : AppCompatActivity() {
    private val gold=Color.rgb(218,178,58)
    private val white=Color.rgb(245,244,240)
    private val muted=Color.rgb(174,174,174)
    private var format="16:9"
    private var style="Cinematic 2D"
    private var scenes=mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?){super.onCreate(savedInstanceState);showEditor()}

    private fun showEditor(){
        val scroll=ScrollView(this).apply{
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(5,5,5),Color.rgb(17,10,10),Color.rgb(4,4,4)))
            isFillViewport=true
        }
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(20),dp(18),dp(28))}
        scroll.addView(root)

        root.addView(TextView(this).apply{
            text="‹  वापस HOME";textSize=13f;setTextColor(gold);setPadding(0,0,0,dp(12));setOnClickListener{finish()}
        })
        root.addView(TextView(this).apply{
            text="👻  HORROR STORY STUDIO";textSize=25f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER
        },lp(0,0,0,4))
        root.addView(TextView(this).apply{
            text="Scenes  →  Characters  →  Dialogue  →  Atmosphere  →  Final Video";textSize=12.5f;setTextColor(muted);gravity=Gravity.CENTER
        },lp(0,0,0,18))

        val script=EditText(this).apply{
            hint="हॉरर कहानी / scene-by-scene script यहाँ लिखें…";minLines=9;gravity=Gravity.TOP
            setTextColor(white);setHintTextColor(Color.rgb(120,120,120));textSize=14f
            background=fieldBackground();setPadding(dp(14),dp(12),dp(14),dp(12))
        }
        root.addView(script,lp(0,0,0,16))

        root.addView(label("INPUT"))
        root.addView(choice("Script + Scene Images",listOf("Script + Scene Images","Recorded Voice + Scene Images","Script + Voice + Scene Images")),lp(0,0,0,12))
        root.addView(label("ANIMATION STYLE"))
        root.addView(choice(style,listOf("Cinematic 2D","3D Horror","Dark Cartoon","Paper / Illustrated","Cinematic Realistic")).apply{
            setOnClickListener{choose(listOf("Cinematic 2D","3D Horror","Dark Cartoon","Paper / Illustrated","Cinematic Realistic")){style=it;text=it}}
        },lp(0,0,0,12))
        root.addView(label("CHARACTER & DIALOGUE"))
        listOf(
            "Use supplied scene images in their given order",
            "Detect character names from scene labels",
            "Pause narration during character dialogue",
            "Play character-specific voice during dialogue",
            "Resume narration after dialogue"
        ).forEach{t->root.addView(CheckBox(this).apply{text=t;isChecked=true;setTextColor(white);buttonTintList=android.content.res.ColorStateList.valueOf(gold)})}
        root.addView(label("FORMAT"))
        root.addView(choice(format,listOf("16:9","9:16")).apply{
            setOnClickListener{choose(listOf("16:9","9:16")){format=it;text=it}}
        },lp(0,0,0,14))

        root.addView(button("🧩  BUILD HORROR SCENE PLAN"){buildPlan(script.text.toString())})
        root.addView(button("👁  PREVIEW SCENES"){showPlan()})
        root.addView(button("🚀  PREPARE FOR AI GENERATION"){
            if(scenes.isEmpty()) buildPlan(script.text.toString(),false)
            AlertDialog.Builder(this).setTitle("Horror Project Ready")
                .setMessage("${scenes.size} scene(s) तैयार हैं.\nStyle: $style\nFormat: $format\n\nAI animation, character voices, lip-sync और final rendering बाद में provider/API adapter से जोड़े जाएंगे.")
                .setPositiveButton("ठीक है",null).show()
        })
        root.addView(TextView(this).apply{
            text="Foundation mode: scene order, dialogue pause/resume और character-voice workflow तैयार है; अभी paid AI API call नहीं होती।"
            textSize=11f;setTextColor(muted);setPadding(dp(4),dp(14),dp(4),0)
        })
        setContentView(scroll)
    }

    private fun buildPlan(raw:String,show:Boolean=true){
        scenes=raw.split(Regex("\\n+|(?<=[.!?।])\\s+")).map{it.trim()}.filter{it.isNotBlank()}.take(40).toMutableList()
        if(scenes.isEmpty()) scenes=mutableListOf("Scene 1 — अपनी horror story/script लिखें।")
        if(show)showPlan()
    }

    private fun showPlan(){
        val text=scenes.mapIndexed{i,s->"SCENE ${i+1}\n$s\nVisual: supplied scene image / selected style\nDialogue: detect & pause narration when marked"}.joinToString("\n\n")
        AlertDialog.Builder(this).setTitle("Horror Scene Plan").setMessage(text).setPositiveButton("ठीक है",null).show()
    }

    private fun button(t:String,click:()->Unit)=Button(this).apply{text=t;textSize=13.5f;isAllCaps=false;setTextColor(white);typeface=Typeface.DEFAULT_BOLD;background=buttonBackground();minimumHeight=dp(50);setOnClickListener{click()}}
    private fun label(t:String)=TextView(this).apply{text=t;textSize=11f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(4),0,dp(7))}
    private fun choice(current:String,options:List<String>)=TextView(this).apply{text=current;textSize=14f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(14),0);background=fieldBackground();minimumHeight=dp(50);setOnClickListener{choose(options){text=it}}}
    private fun choose(options:List<String>,result:(String)->Unit){AlertDialog.Builder(this).setTitle("चयन करें").setItems(options.toTypedArray()){_,i->result(options[i])}.show()}
    private fun fieldBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(22,22,22),Color.rgb(14,14,14))).apply{cornerRadius=dp(13).toFloat();setStroke(dp(1),Color.rgb(64,58,42))}
    private fun buttonBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(39,34,23),Color.rgb(20,20,20))).apply{cornerRadius=dp(14).toFloat();setStroke(dp(1),gold)}
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(l),dp(t),dp(r),dp(b))}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}

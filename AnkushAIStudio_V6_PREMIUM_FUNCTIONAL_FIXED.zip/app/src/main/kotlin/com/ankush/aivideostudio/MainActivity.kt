package com.ankush.aivideostudio

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val gold = Color.rgb(218, 178, 58)
    private val white = Color.rgb(245, 244, 240)
    private val muted = Color.rgb(174, 174, 174)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
    }

    private fun buildHome() {
        val scroll = ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5,5,5), Color.rgb(16,14,10), Color.rgb(4,4,4))
            )
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(30))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "ANKUSH AI VIDEO STUDIO"
            textSize = 25f
            setTextColor(gold)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = .04f
        }, lp(0,0,0,4))

        root.addView(TextView(this).apply {
            text = "आपका निजी AI वीडियो प्रोडक्शन स्टूडियो"
            textSize = 16f
            setTextColor(white)
            gravity = Gravity.CENTER
        }, lp(0,0,0,5))

        root.addView(TextView(this).apply {
            text = "NEWS  •  SPIRITUAL  •  FINANCE  •  COMEDY  •  DOCUMENTARY  •  HORROR"
            textSize = 9.5f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }, lp(0,0,0,18))

        val studios = listOf(
            arrayOf("01", "📰", "चित्रकूट न्यूज़", "News Presenter  •  Interview  •  Guest"),
            arrayOf("02", "🔱", "वैदिक एवं तांत्रिक ज्ञान", "Presenter  •  प्रश्न–उत्तर  •  Podcast"),
            arrayOf("03", "📈", "Buycryptohub", "Stock  •  Crypto  •  Presenter"),
            arrayOf("04", "😂", "Comedy Conversation", "Character 1  •  Character 2  •  Dialogue"),
            arrayOf("05", "🎞", "Editorial Explainer", "Story  →  Scenes  →  Visuals  →  Motion"),
            arrayOf("06", "👻", "Horror Story Studio", "Scenes  •  Characters  •  Dialogue  •  Atmosphere")
        )

        studios.forEachIndexed { index, item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(13), dp(12), dp(13))
                background = cardBackground()
                elevation = dp(3).toFloat()
                isClickable = true
                setOnClickListener {
                    when (index) {
                        4 -> startActivity(Intent(this@MainActivity, ExplainerActivity::class.java))
                        5 -> startActivity(Intent(this@MainActivity, HorrorActivity::class.java))
                        else -> startActivity(Intent(this@MainActivity, StudioActivity::class.java).apply {
                            putExtra("studioIndex", index)
                            putExtra("studioName", item[2])
                        })
                    }
                }
            }

            val badge = TextView(this).apply {
                text = item[0]
                textSize = 11f
                setTextColor(Color.BLACK)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(gold)
                }
            }
            card.addView(badge, LinearLayout.LayoutParams(dp(34), dp(34)).apply {
                setMargins(0,0,dp(12),0)
            })

            card.addView(TextView(this).apply {
                text = item[1]
                textSize = 20f
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(32), dp(48)).apply {
                setMargins(0,0,dp(4),0)
            })

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
            }
            info.addView(TextView(this).apply {
                text = item[2]
                textSize = 17f
                setTextColor(white)
                typeface = Typeface.DEFAULT_BOLD
            })
            info.addView(TextView(this).apply {
                text = item[3]
                textSize = 11.5f
                setTextColor(muted)
                setPadding(0, dp(4), 0, 0)
            })
            card.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            card.addView(TextView(this).apply {
                text = "खोलें  ›"
                textSize = 11f
                setTextColor(gold)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(58), dp(48)))

            root.addView(card, lp(0,0,0,10))
        }

        val status = TextView(this).apply {
            text = "✦  V6 PREMIUM FOUNDATION  •  WORKFLOW READY"
            textSize = 11.5f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(5))
        }
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "सभी project settings अभी local रूप से सुरक्षित की जा सकती हैं। AI voice, avatar, lip-sync और rendering को बाद में provider/API adapter से जोड़ा जाएगा।"
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(8),0,dp(8),0)
        })

        setContentView(scroll)
    }

    private fun cardBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(24,22,18), Color.rgb(13,13,13))
    ).apply {
        cornerRadius = dp(18).toFloat()
        setStroke(dp(1), Color.rgb(106,85,34))
    }

    private fun lp(l:Int,t:Int,r:Int,b:Int) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(l),dp(t),dp(r),dp(b))
        }

    private fun dp(v:Int)= (v * resources.displayMetrics.density).toInt()
}

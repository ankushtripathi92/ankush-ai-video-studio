package com.ankush.aivideostudio

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class StudioActivity : Activity() {
    private val gold = Color.rgb(212, 175, 55)
    private val bg = Color.rgb(10, 10, 10)
    private val card = Color.rgb(35, 35, 35)
    private lateinit var studio: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        studio = intent.getStringExtra("studio") ?: "NEWS"
        buildStudio()
    }

    private fun buildStudio() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(18, 28, 18, 24)
        }
        root.addView(TextView(this).apply {
            text = studioTitle()
            textSize = 23f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 22)
        })

        when (studio) {
            "NEWS" -> {
                addFeature(root, "🎬 FULL NEWS PRESENTER", "FULL_PRESENTER")
                addFeature(root, "🎙️ INTERVIEW / EXPERT MODE", "INTERVIEW")
                addFeature(root, "👩 ANCHOR LIBRARY", "ANCHOR")
                addFeature(root, "🖼️ PHOTOS / VIDEOS / SCREENSHOTS", "MEDIA")
                addFeature(root, "📝 SCRIPT", "SCRIPT")
                addFeature(root, "🎙️ VOICE / VOICE CLONE", "VOICE")
                addFeature(root, "📐 16:9 / 9:16", "ASPECT")
            }
            "VEDIC" -> {
                addFeature(root, "🎬 FULL PRESENTER", "FULL_PRESENTER")
                addFeature(root, "🎙️ प्रश्न–उत्तर / PODCAST", "INTERVIEW")
                addFeature(root, "👩 FEMALE ANCHOR LIBRARY", "ANCHOR")
                addFeature(root, "👤 ANKUSH SHASTRI AVATAR", "ANCHOR")
                addFeature(root, "📝 SCRIPT", "SCRIPT")
                addFeature(root, "🖼️ BACKGROUND / MEDIA", "MEDIA")
                addFeature(root, "📐 16:9 / 9:16", "ASPECT")
            }
            "FINANCE" -> {
                addFeature(root, "🎬 CENTER PRESENTER", "FULL_PRESENTER")
                addFeature(root, "📊 SPLIT SCREEN", "INTERVIEW")
                addFeature(root, "🖼️ INFORMATION SCREENSHOTS", "MEDIA")
                addFeature(root, "🧠 SCRIPT → VISUAL MATCHING", "SCRIPT")
                addFeature(root, "🎙️ MY VOICE / VOICE CLONE", "VOICE")
                addFeature(root, "📈 STOCK / CRYPTO BACKGROUND", "MEDIA")
                addFeature(root, "📐 16:9 / 9:16", "ASPECT")
            }
            else -> {
                addFeature(root, "👤 CHARACTER 01", "ANCHOR")
                addFeature(root, "👤 CHARACTER 02", "ANCHOR")
                addFeature(root, "💬 DIALOGUE / SCRIPT", "SCRIPT")
                addFeature(root, "🎭 CHARACTER STYLE", "ANCHOR")
                addFeature(root, "🎙️ VOICE", "VOICE")
                addFeature(root, "⏱️ DURATION", "FULL_PRESENTER")
                addFeature(root, "📐 16:9 / 9:16", "ASPECT")
            }
        }
        addFeature(root, "▶ PREVIEW / GENERATE", "PREVIEW", true)
        setContentView(root)
    }

    private fun studioTitle() = when (studio) {
        "NEWS" -> "📰 चित्रकूट न्यूज़ Studio"
        "VEDIC" -> "🔱 वैदिक एवं तांत्रिक ज्ञान Studio"
        "FINANCE" -> "📈 Buycryptohub Studio"
        else -> "😂 Comedy Conversation Studio"
    }

    private fun addFeature(parent: LinearLayout, label: String, feature: String, primary: Boolean = false) {
        val b = Button(this).apply {
            text = label
            textSize = if (primary) 16f else 14f
            setTextColor(if (primary) Color.BLACK else Color.WHITE)
            setBackgroundColor(if (primary) gold else card)
            setOnClickListener {
                startActivity(Intent(this@StudioActivity, FeatureActivity::class.java).apply {
                    putExtra("studio", studio)
                    putExtra("feature", feature)
                })
            }
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, 9)
        parent.addView(b, lp)
    }
}

package com.ankush.aivideostudio

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FeatureActivity : Activity() {
    private val gold = Color.rgb(212, 175, 55)
    private val bg = Color.rgb(10, 10, 10)
    private val card = Color.rgb(32, 32, 32)
    private val prefs by lazy { getSharedPreferences("project", MODE_PRIVATE) }
    private lateinit var studio: String
    private lateinit var feature: String
    private lateinit var root: LinearLayout
    private var mediaCount = 0
    private var selectedAnchor = "आर्या — Female News Anchor"
    private var selectedVoice = "Natural Female Hindi"
    private var selectedAspect = "16:9"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        studio = intent.getStringExtra("studio") ?: "NEWS"
        feature = intent.getStringExtra("feature") ?: "PREVIEW"
        selectedAnchor = prefs.getString(key("anchor"), selectedAnchor) ?: selectedAnchor
        selectedVoice = prefs.getString(key("voice"), selectedVoice) ?: selectedVoice
        selectedAspect = prefs.getString(key("aspect"), selectedAspect) ?: selectedAspect
        build()
    }

    private fun key(name: String) = "${studio.lowercase()}_$name"

    private fun build() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(18, 26, 18, 24)
        }
        val title = TextView(this).apply {
            text = featureTitle()
            textSize = 22f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        root.addView(title)
        addBack(root)
        when (feature) {
            "SCRIPT" -> scriptScreen()
            "MEDIA" -> mediaScreen()
            "ANCHOR" -> anchorScreen()
            "VOICE" -> voiceScreen()
            "ASPECT" -> aspectScreen()
            "INTERVIEW" -> interviewScreen()
            "FULL_PRESENTER" -> presenterScreen()
            else -> previewScreen()
        }
        setContentView(root)
    }

    private fun addBack(parent: LinearLayout) {
        val b = Button(this).apply {
            text = "← वापस Studio"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(45, 45, 45))
            setOnClickListener { finish() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 14) })
    }

    private fun featureTitle() = when (feature) {
        "SCRIPT" -> "📝 Script Editor"
        "MEDIA" -> "🖼️ Media Library"
        "ANCHOR" -> "👩 Anchor / Character Library"
        "VOICE" -> "🎙️ Voice Library"
        "ASPECT" -> "📐 Video Format"
        "INTERVIEW" -> "🎙️ Interview / Dialogue Setup"
        "FULL_PRESENTER" -> "🎬 Presenter Setup"
        else -> "▶ Project Preview / Generate"
    }

    private fun addLabel(text: String) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(4, 8, 4, 8)
        })
    }

    private fun addButton(text: String, action: () -> Unit, primary: Boolean = false) {
        root.addView(Button(this).apply {
            this.text = text
            textSize = if (primary) 16f else 14f
            setTextColor(if (primary) Color.BLACK else Color.WHITE)
            setBackgroundColor(if (primary) gold else card)
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 7) })
    }

    private fun scriptScreen() {
        addLabel("पूरी न्यूज़/वीडियो स्क्रिप्ट यहाँ लिखें या पेस्ट करें। यह स्क्रिप्ट इसी Studio के लिए लोकल रूप से सेव होगी।")

        val title = field("Script title / episode name", prefs.getString(key("script_title"), prefs.getString("script_title", "")))
        root.addView(title)

        val edit = EditText(this).apply {
            setText(prefs.getString(key("script"), prefs.getString("script", "")))
            hint = "यहाँ अपनी पूरी स्क्रिप्ट लिखें..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(28, 28, 28))
            gravity = Gravity.TOP
            minLines = 13
            setPadding(16, 16, 16, 16)
        }
        root.addView(edit, LinearLayout.LayoutParams(-1, 0, 1f))

        val stats = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(6, 8, 6, 4)
        }
        root.addView(stats)

        fun updateStats() {
            val text = edit.text.toString().trim()
            val chars = text.length
            val words = if (text.isBlank()) 0 else text.split(Regex("\\s+")).size
            val minutes = if (words == 0) 0.0 else words / 130.0
            stats.text = "Characters: $chars  •  Words: $words  •  अनुमानित बोलने का समय: ${String.format(java.util.Locale.US, "%.1f", minutes)} मिनट"
        }
        updateStats()
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateStats() }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        addButton("💾 SAVE SCRIPT", {
            prefs.edit()
                .putString(key("script_title"), title.text.toString())
                .putString(key("script"), edit.text.toString())
                .apply()
            Toast.makeText(this, "स्क्रिप्ट सेव हो गई", Toast.LENGTH_SHORT).show()
        }, true)

        addButton("📄 SAMPLE NEWS SCRIPT डालें", {
            title.setText("भारत की आज की प्रमुख खबरें")
            edit.setText(sampleNewsScript())
            edit.setSelection(edit.text.length)
            Toast.makeText(this, "Sample script डाली गई — अब इसे बदल सकते हैं", Toast.LENGTH_SHORT).show()
        })

        addButton("🧹 SCRIPT CLEAR करें", {
            title.setText("")
            edit.setText("")
        })
    }

    private fun sampleNewsScript(): String = """
नमस्कार, आप देख रहे हैं चित्रकूट न्यूज़।
मैं हूँ आपकी समाचार प्रस्तोता आर्या।
आज की प्रमुख खबरों में देश, समाज और इतिहास से जुड़ी महत्वपूर्ण जानकारियों पर नजर डालेंगे।

पहली खबर...
यहाँ अपनी खबर का मुख्य विवरण लिखें।

दूसरी खबर...
यहाँ दूसरी खबर का विवरण और आवश्यक तथ्य लिखें।

अब बढ़ते हैं आज की अगली महत्वपूर्ण खबर की ओर।

अंत में, पूरी जानकारी और स्रोतों की पुष्टि के बाद ही किसी निष्कर्ष पर पहुँचें।
धन्यवाद। जय हिंद।
""".trimIndent()

    private fun mediaScreen() {
        addLabel("फोन से फोटो, वीडियो या स्क्रीनशॉट चुनें। Multiple files भी चुन सकते हैं।")
        val status = TextView(this).apply {
            text = "चुनी गई फाइलें: 0"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(8, 16, 8, 16)
        }
        root.addView(status)
        addButton("➕ PHONE MEDIA चुनें", {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(intent, 1001)
        }, true)
        addButton("🧹 चयन रीसेट करें", {
            mediaCount = 0
            status.text = "चुनी गई फाइलें: 0"
        })
        addLabel("नोट: V3 में यह लोकल media selection layer है। AI video generation engine अगले चरण में जोड़ा जाएगा।")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == 1001) {
            mediaCount = data.clipData?.itemCount ?: if (data.data != null) 1 else 0
            Toast.makeText(this, "${mediaCount} media file(s) चुनी गई", Toast.LENGTH_SHORT).show()
        } else if (requestCode == 1002) {
            Toast.makeText(this, "Voice sample चुना गया", Toast.LENGTH_SHORT).show()
        }
    }

    private fun anchorScreen() {
        addLabel("एक fixed presenter/character चुनें। आगे चलकर इसी library में reference images और identity settings जुड़ेंगे।")
        val names = if (studio == "NEWS") listOf("आर्या — Female News Anchor", "नंदिनी — Female News Anchor", "काव्या — Female News Anchor")
        else if (studio == "VEDIC") listOf("आर्या — Female Spiritual Anchor", "अंकुश शास्त्री — Avatar", "नंदिनी — Female Anchor")
        else if (studio == "FINANCE") listOf("Finance Presenter — Male", "Finance Presenter — Female", "My Avatar — Reserved")
        else listOf("Character 01", "Character 02", "Character 03")
        names.forEach { name ->
            addButton(if (name == selectedAnchor) "✓ $name" else name, {
                selectedAnchor = name
                prefs.edit().putString(key("anchor"), name).apply()
                Toast.makeText(this, "चयन: $name", Toast.LENGTH_SHORT).show()
                build()
            })
        }
        addLabel("चयनित: $selectedAnchor")
    }

    private fun voiceScreen() {
        addLabel("Voice profile चुनें। असली voice clone/API को बाद में सुरक्षित provider adapter से जोड़ा जाएगा।")
        listOf("Natural Female Hindi", "Professional Male Hindi", "My Voice Clone — Reserved", "Custom Voice — Reserved").forEach { v ->
            addButton(if (v == selectedVoice) "✓ $v" else v, {
                selectedVoice = v
                prefs.edit().putString(key("voice"), v).apply()
                Toast.makeText(this, "Voice चयन: $v", Toast.LENGTH_SHORT).show()
                build()
            })
        }
        addButton("🎧 VOICE SAMPLE चुनें", {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "audio/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(intent, 1002)
        })
        addLabel("चयनित Voice: $selectedVoice")
    }

    private fun aspectScreen() {
        addLabel("Video का final canvas चुनें।")
        addButton(if (selectedAspect == "16:9") "✓ 16:9 Landscape" else "16:9 Landscape", {
            selectedAspect = "16:9"; saveAspect(); build()
        })
        addButton(if (selectedAspect == "9:16") "✓ 9:16 Portrait / Shorts" else "9:16 Portrait / Shorts", {
            selectedAspect = "9:16"; saveAspect(); build()
        })
        addLabel("चयनित format: $selectedAspect")
    }

    private fun saveAspect() { prefs.edit().putString(key("aspect"), selectedAspect).apply() }

    private fun presenterScreen() {
        addLabel("Presenter project की मूल जानकारी सेट करें।")
        val headline = field("Headline / Topic", prefs.getString(key("headline"), prefs.getString("headline", "")))
        val duration = field("Duration (जैसे 5, 10, 15 मिनट)", prefs.getString(key("duration"), prefs.getString("duration", "10")))
        val note = field("Scene / visual notes", prefs.getString(key("visuals"), prefs.getString("visuals", "")))
        root.addView(headline)
        root.addView(duration)
        root.addView(note)
        addButton("💾 SAVE PRESENTER PROJECT", {
            prefs.edit().putString(key("headline"), headline.text.toString()).putString(key("duration"), duration.text.toString()).putString(key("visuals"), note.text.toString()).apply()
            Toast.makeText(this, "Presenter project सेव हो गया", Toast.LENGTH_SHORT).show()
        }, true)
        addButton("▶ PREVIEW PROJECT", { previewScreen() })
    }

    private fun field(hintText: String, value: String?): EditText = EditText(this).apply {
        hint = hintText
        setText(value ?: "")
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        setBackgroundColor(Color.rgb(28, 28, 28))
        setPadding(14, 12, 14, 12)
    }

    private fun interviewScreen() {
        addLabel("Interview mode में anchor, guest और प्रश्नों की रूपरेखा तैयार करें।")
        val guest = field("Guest / Expert का नाम", prefs.getString(key("guest"), prefs.getString("guest", "")))
        val questions = field("Questions (एक-एक लाइन में)", prefs.getString(key("questions"), prefs.getString("questions", "")))
        questions.minLines = 8
        questions.gravity = Gravity.TOP
        root.addView(guest)
        root.addView(questions)
        addButton("💾 SAVE INTERVIEW", {
            prefs.edit().putString(key("guest"), guest.text.toString()).putString(key("questions"), questions.text.toString()).apply()
            Toast.makeText(this, "Interview setup सेव हो गया", Toast.LENGTH_SHORT).show()
        }, true)
        addLabel("उत्तर आप खुद रिकॉर्ड कर सकते हैं या आगे AI guest/voice adapter से जोड़े जा सकते हैं।")
    }

    private fun previewScreen() {
        val script = prefs.getString(key("script"), prefs.getString("script", "")) ?: ""
        val headline = prefs.getString(key("headline"), prefs.getString("headline", "")) ?: ""
        val duration = prefs.getString(key("duration"), prefs.getString("duration", "10")) ?: "10"
        val anchor = prefs.getString(key("anchor"), selectedAnchor) ?: selectedAnchor
        val voice = prefs.getString(key("voice"), selectedVoice) ?: selectedVoice
        val aspect = prefs.getString(key("aspect"), selectedAspect) ?: selectedAspect
        val scriptTitle = prefs.getString(key("script_title"), "") ?: ""
        addLabel("PROJECT SUMMARY")
        val summary = TextView(this).apply {
            text = "Studio: ${studioName()}\nHeadline: ${headline.ifBlank { "अभी सेट नहीं" }}\nScript: ${if (script.isBlank()) "अभी नहीं" else "सेट है (${script.length} characters)"}${if (scriptTitle.isBlank()) "" else "\nScript Title: $scriptTitle"}\nPresenter: $anchor\nVoice: $voice\nFormat: $aspect\nDuration: $duration मिनट\nMedia: $mediaCount file(s)"
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(28, 28, 28))
            setPadding(16, 16, 16, 16)
        }
        root.addView(summary)
        addButton("💾 SAVE PROJECT", {
            prefs.edit().putString("lastStudio", studio).apply()
            Toast.makeText(this, "Project local storage में सेव हो गया", Toast.LENGTH_SHORT).show()
        }, true)
        addButton("🚀 PREPARE FOR AI GENERATION", {
            Toast.makeText(this, "Project तैयार है। AI Engine adapter अभी connect नहीं है।", Toast.LENGTH_LONG).show()
        })
        addLabel("यह V3 local project layer है। किसी paid AI provider को बिना आपकी अनुमति के call नहीं किया जाता।")
    }

    private fun studioName() = when (studio) {
        "NEWS" -> "चित्रकूट न्यूज़"
        "VEDIC" -> "वैदिक एवं तांत्रिक ज्ञान"
        "FINANCE" -> "Buycryptohub"
        else -> "Comedy Conversation"
    }
}

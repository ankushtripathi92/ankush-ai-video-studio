# Ankush AI Video Studio — V3

Android-first foundation for:
- Chitrakoot News
- Vaidik & Tantrik Gyan
- Buycryptohub
- Comedy Conversation

## V3 focus
- Functional Studio-specific Script Editor
- Script title + full multiline script
- Live character/word count
- Approximate speaking-time estimate
- Save script locally per Studio
- Sample Hindi news script button
- Clear script button
- Existing presenter, anchor, voice, media, aspect ratio and preview foundation retained
- Version 0.3.0 / versionCode 3

## Important
This version does not automatically call any paid AI provider. The AI engine adapter, voice generation, avatar/lip-sync and final video rendering are planned for later phases.

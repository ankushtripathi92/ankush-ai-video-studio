# Ankush AI Video Studio — V11 Real Presenter Engine Bridge

V11 continues the stable V10 New Project Flow.

## Main new feature
The Chitrakoot News presenter workflow now has a dedicated **Real Presenter Engine Bridge**.

Pipeline:
Master Presenter Photo
→ Narration Audio
→ Story / Expression Plan
→ AI Engine Adapter Request
→ Future facial animation / lip-sync provider
→ Final presenter video

## New V11 functions
- Master presenter photo preview
- Female AI News Anchor / My AI Avatar / Guest profile
- Local narration recording (M4A)
- Import existing narration audio
- Engine adapter selection
- Story-aware expression timeline
- Presenter readiness checklist
- JSON AI Presenter Request Package
- Local production-plan preview
- ProjectStore persistence for narration audio

## Important limitation
The APK does not contain a large AI video model and does not call a paid provider by itself.
The engine bridge is provider-neutral so a suitable open-source/free or paid engine can be
connected later without rebuilding the whole app architecture.

## GitHub build
Workflow expects:
`AnkushAIStudio_V11_REAL_PRESENTER_ENGINE_BRIDGE.zip`

The GitHub Actions workflow builds:
`app-debug.apk`


V12 REAL PRESENTER GENERATION FOUNDATION
- Master presenter photo, narration, expression planning, engine adapter selection, local motion concept preview, request-package generation and JSON export.
- Final AI facial animation is intentionally provider-neutral and must be connected through a licensed model/provider adapter.

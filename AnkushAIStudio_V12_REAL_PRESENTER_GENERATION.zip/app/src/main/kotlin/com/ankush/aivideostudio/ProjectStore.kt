package com.ankush.aivideostudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class SavedProject(
    val id: String,
    val studioIndex: Int,
    val studioName: String,
    val headline: String,
    val duration: String,
    val script: String,
    val format: String,
    val mediaNames: List<String>,
    val updatedAt: Long,
    val presenterType: String = "Female AI News Anchor",
    val presenterImage: String = "",
    val voiceProfile: String = "Natural Hindi Female",
    val expressionMode: String = "Story-Aware Auto",
    val storyTone: String = "Auto Detect",
    val expressionPlan: String = "",
    val generationStatus: String = "AI Engine Adapter Ready",
    val narrationAudio: String = ""
)

object ProjectStore {
    private const val PREFS = "ankush_projects_v8"
    private const val KEY = "projects"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun all(context: Context): MutableList<SavedProject> {
        val raw = prefs(context).getString(KEY, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val result = mutableListOf<SavedProject>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val media = mutableListOf<String>()
            val mediaArr = o.optJSONArray("media")
            if (mediaArr != null) {
                for (j in 0 until mediaArr.length()) media.add(mediaArr.optString(j))
            }
            result.add(
                SavedProject(
                    id = o.optString("id"),
                    studioIndex = o.optInt("studioIndex", 0),
                    studioName = o.optString("studioName", "STUDIO"),
                    headline = o.optString("headline", ""),
                    duration = o.optString("duration", "5"),
                    script = o.optString("script", ""),
                    format = o.optString("format", "16:9"),
                    mediaNames = media,
                    updatedAt = o.optLong("updatedAt", 0L),
                    presenterType = o.optString("presenterType", "Female AI News Anchor"),
                    presenterImage = o.optString("presenterImage", ""),
                    voiceProfile = o.optString("voiceProfile", "Natural Hindi Female"),
                    expressionMode = o.optString("expressionMode", "Story-Aware Auto"),
                    storyTone = o.optString("storyTone", "Auto Detect"),
                    expressionPlan = o.optString("expressionPlan", ""),
                    generationStatus = o.optString("generationStatus", "AI Engine Adapter Ready"),
                    narrationAudio = o.optString("narrationAudio", "")
                )
            )
        }
        return result.sortedByDescending { it.updatedAt }.toMutableList()
    }

    fun save(context: Context, project: SavedProject): String {
        val list = all(context)
        val id = if (project.id.isBlank()) UUID.randomUUID().toString() else project.id
        val saved = project.copy(id = id, updatedAt = System.currentTimeMillis())
        val index = list.indexOfFirst { it.id == id }
        if (index >= 0) list[index] = saved else list.add(saved)
        write(context, list)
        return id
    }

    fun delete(context: Context, id: String) {
        write(context, all(context).filter { it.id != id })
    }

    fun duplicate(context: Context, id: String): String? {
        val original = all(context).firstOrNull { it.id == id } ?: return null
        return save(context, original.copy(id = "", headline = if (original.headline.isBlank()) "कॉपी" else "${original.headline} — कॉपी"))
    }

    fun find(context: Context, id: String): SavedProject? =
        all(context).firstOrNull { it.id == id }

    private fun write(context: Context, list: List<SavedProject>) {
        val arr = JSONArray()
        list.sortedByDescending { it.updatedAt }.forEach { p ->
            val o = JSONObject()
            o.put("id", p.id)
            o.put("studioIndex", p.studioIndex)
            o.put("studioName", p.studioName)
            o.put("headline", p.headline)
            o.put("duration", p.duration)
            o.put("script", p.script)
            o.put("format", p.format)
            o.put("updatedAt", p.updatedAt)
            o.put("presenterType", p.presenterType)
            o.put("presenterImage", p.presenterImage)
            o.put("voiceProfile", p.voiceProfile)
            o.put("expressionMode", p.expressionMode)
            o.put("storyTone", p.storyTone)
            o.put("expressionPlan", p.expressionPlan)
            o.put("generationStatus", p.generationStatus)
            o.put("narrationAudio", p.narrationAudio)
            val media = JSONArray()
            p.mediaNames.forEach { media.put(it) }
            o.put("media", media)
            arr.put(o)
        }
        prefs(context).edit().putString(KEY, arr.toString()).apply()
    }
}

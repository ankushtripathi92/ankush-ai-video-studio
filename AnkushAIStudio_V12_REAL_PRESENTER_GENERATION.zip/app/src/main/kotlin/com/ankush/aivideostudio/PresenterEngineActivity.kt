package com.ankush.aivideostudio

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PresenterEngineActivity : AppCompatActivity() {
    private val gold = Color.rgb(218,178,58)
    private val white = Color.rgb(245,244,240)
    private val muted = Color.rgb(174,174,174)

    private var projectId = ""
    private var project: SavedProject? = null
    private var selectedEngine = "Local Motion Preview"
    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var isRecording = false
    private lateinit var root: LinearLayout
    private lateinit var recordButton: Button
    private lateinit var statusText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var previewRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectId = intent.getStringExtra("projectId") ?: ""
        project = ProjectStore.find(this, projectId)
        build()
    }

    private fun build() {
        val p = project
        val scroll = ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5,5,5), Color.rgb(18,15,10), Color.rgb(4,4,4))
            )
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "‹  वापस PRESENTER"
            textSize = 13f
            setTextColor(gold)
            setOnClickListener { finish() }
        }, lp(0,0,0,12))

        root.addView(TextView(this).apply {
            text = "REAL PRESENTER ENGINE"
            textSize = 25f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, lp(0,0,0,4))

        root.addView(TextView(this).apply {
            text = "V12 • Presenter generation pipeline"
            textSize = 12.5f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }, lp(0,0,0,16))

        root.addView(infoCard("PROJECT", p?.headline?.ifBlank { "Untitled Project" } ?: "Project not found"))
        root.addView(infoCard("PRESENTER", p?.presenterType ?: "Not selected"))
        root.addView(infoCard("FORMAT", p?.format ?: "16:9"))
        root.addView(infoCard("DURATION", "${p?.duration ?: "5"} मिनट"))

        root.addView(label("MASTER PRESENTER"))
        root.addView(actionButton("🖼️  SELECT / CHANGE MASTER PHOTO") { pickMasterPhoto() })
        root.addView(infoCard("MASTER PHOTO", if (p?.presenterImage.isNullOrBlank()) "⚠ Photo अभी चयनित नहीं" else "✓ Master presenter photo ready"))

        val image = ImageView(this).apply {
            minimumHeight = dp(230)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = fieldBackground()
            val uri = p?.presenterImage?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
            if (uri != null) setImageURI(uri)
        }
        root.addView(image, lp(0,0,0,14))

        root.addView(label("VOICE / NARRATION"))
        root.addView(infoCard("VOICE PROFILE", p?.voiceProfile ?: "Natural Hindi Female"))
        root.addView(infoCard("NARRATION", if (p?.narrationAudio.isNullOrBlank()) "अभी audio attached नहीं" else "✓ Narration audio ready"))
        recordButton = actionButton("🎙  START VOICE RECORDING") { toggleRecording() }
        root.addView(recordButton, lp(0,0,0,8))
        root.addView(actionButton("🎧  IMPORT AUDIO FILE") { pickAudio() }, lp(0,0,0,12))

        root.addView(label("STORY-AWARE PERFORMANCE"))
        root.addView(infoCard("TONE", p?.storyTone ?: "Auto Detect"))
        root.addView(infoCard("EXPRESSION MODE", p?.expressionMode ?: "Story-Aware Auto"))
        root.addView(infoCard("EXPRESSION PLAN",
            if (p?.expressionPlan.isNullOrBlank()) "पहले Analyze Story → Expression Plan चलाएँ"
            else p!!.expressionPlan.take(900)))

        root.addView(actionButton("🎭  GENERATE / REFRESH EXPRESSION TIMELINE") {
            val current = ProjectStore.find(this, projectId)
            if (current == null) {
                toast("Project नहीं मिला")
            } else if (current.script.isBlank()) {
                toast("पहले news script डालें")
            } else {
                val plan = buildExpressionPlan(current.script)
                ProjectStore.save(this, current.copy(
                    expressionPlan = plan,
                    storyTone = detectTone(current.script),
                    generationStatus = "Expression timeline ready • Presenter engine ready"
                ))
                project = ProjectStore.find(this, projectId)
                toast("Expression timeline तैयार है")
                build()
            }
        }, lp(0,0,0,12))

        root.addView(label("ENGINE ADAPTER"))
        val engineChoice = choice(selectedEngine)
        engineChoice.setOnClickListener {
            choose(
                listOf(
                    "Local Motion Preview",
                    "SadTalker Adapter (local/remote)",
                    "Custom HTTPS AI API Adapter",
                    "Future Provider Adapter"
                )
            ) {
                selectedEngine = it
                engineChoice.text = it
                statusText.text = "Engine: $it"
            }
        }
        root.addView(engineChoice, lp(0,0,0,12))

        root.addView(label("GENERATION READINESS"))
        root.addView(checkCard("✓", "Master presenter identity", !p?.presenterImage.isNullOrBlank()))
        root.addView(checkCard("✓", "Full narration script", !p?.script.isNullOrBlank()))
        root.addView(checkCard("✓", "Narration audio", !p?.narrationAudio.isNullOrBlank()))
        root.addView(checkCard("✓", "Story-aware expression plan", !p?.expressionPlan.isNullOrBlank()))
        root.addView(checkCard("✓", "Output format", !p?.format.isNullOrBlank()))
        root.addView(checkCard("✓", "Presenter request builder", true))
        root.addView(checkCard("•", "External AI facial-animation model", false,
            "Actual model/provider connection अभी अलग adapter के रूप में जोड़ा जाएगा"))

        statusText = TextView(this).apply {
            text = "Engine: $selectedEngine"
            textSize = 11f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        root.addView(statusText)

        root.addView(actionButton("▶  REALISTIC MOTION PREVIEW") {
            showMotionPreview(image)
        }, lp(0,0,0,8))

        root.addView(actionButton("📦  BUILD AI PRESENTER REQUEST") {
            buildRequestPackage()
        }, lp(0,0,0,8))

        root.addView(actionButton("💾  EXPORT PRESENTER JOB JSON") {
            exportRequestPackage()
        }, lp(0,0,0,8))

        root.addView(actionButton("▶  PRESENTER PRODUCTION PREVIEW") {
            showProductionPreview()
        }, lp(0,0,0,8))

        root.addView(TextView(this).apply {
            text = "V12 लक्ष्य: fixed presenter identity + narration + story-aware performance → AI facial-animation engine → final presenter MP4. Local Motion Preview केवल movement concept दिखाता है; यह final AI face animation नहीं है."
            textSize = 10.5f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), 0)
        })
        setContentView(scroll)
    }

    private fun pickMasterPhoto() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, 704
        )
    }

    private fun toggleRecording() {
        if (isRecording) stopRecording() else startRecording()
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 700)
            return
        }
        try {
            val dir = File(filesDir, "recordings")
            if (!dir.exists()) dir.mkdirs()
            recordingFile = File(dir, "narration_${System.currentTimeMillis()}.m4a")
            recorder = MediaRecorder(this).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(128000)
                setOutputFile(recordingFile!!.absolutePath)
                prepare()
                start()
            }
            isRecording = true
            recordButton.text = "⏹  STOP VOICE RECORDING"
            statusText.text = "Recording narration…"
        } catch (e: Exception) {
            recorder?.release()
            recorder = null
            recordingFile = null
            isRecording = false
            toast("Recording शुरू नहीं हो सकी: ${e.message ?: "unknown error"}")
        }
    }

    private fun stopRecording() {
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release()
        recorder = null
        isRecording = false
        val path = recordingFile?.absolutePath ?: ""
        if (path.isNotBlank()) {
            val current = ProjectStore.find(this, projectId)
            if (current != null) {
                ProjectStore.save(this, current.copy(
                    narrationAudio = path,
                    generationStatus = "Narration audio ready • Presenter engine ready"
                ))
                project = ProjectStore.find(this, projectId)
            }
        }
        recordButton.text = "🎙  START VOICE RECORDING"
        statusText.text = "Narration audio saved locally"
        toast("Voice recording सेव हो गई")
    }

    private fun pickAudio() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "audio/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, 703
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        val current = ProjectStore.find(this, projectId) ?: return
        when (requestCode) {
            703 -> ProjectStore.save(this, current.copy(
                narrationAudio = uri.toString(),
                generationStatus = "Imported narration audio ready • Presenter engine ready"
            ))
            704 -> ProjectStore.save(this, current.copy(
                presenterImage = uri.toString(),
                generationStatus = "Master presenter photo ready • Presenter engine ready"
            ))
        }
        project = ProjectStore.find(this, projectId)
        build()
    }

    private fun buildRequestPackage(): File? {
        val p = ProjectStore.find(this, projectId)
        if (p == null) {
            toast("Project नहीं मिला"); return null
        }
        if (p.presenterImage.isBlank()) {
            toast("पहले Master Presenter Photo चुनें"); return null
        }
        if (p.script.isBlank()) {
            toast("पहले पूरा news script डालें"); return null
        }
        val obj = JSONObject()
        obj.put("app", "Ankush AI Video Studio")
        obj.put("version", "V12")
        obj.put("pipeline", "Real Presenter Generation")
        obj.put("projectId", p.id)
        obj.put("studio", p.studioName)
        obj.put("presenterType", p.presenterType)
        obj.put("presenterImage", p.presenterImage)
        obj.put("voiceProfile", p.voiceProfile)
        obj.put("narrationAudio", p.narrationAudio)
        obj.put("script", p.script)
        obj.put("headline", p.headline)
        obj.put("durationMinutes", p.duration)
        obj.put("format", p.format)
        obj.put("storyTone", p.storyTone)
        obj.put("expressionMode", p.expressionMode)
        obj.put("expressionPlan", p.expressionPlan)
        obj.put("engineAdapter", selectedEngine)
        obj.put("requestedOutput", "MP4")
        obj.put("faceMotion", "natural_lips_eyes_blink_jaw_head_expression")
        obj.put("createdAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date()))
        val file = File(filesDir, "presenter_request_${p.id}.json")
        file.writeText(obj.toString(2))
        ProjectStore.save(this, p.copy(generationStatus = "Presenter request ready • $selectedEngine"))
        project = ProjectStore.find(this, projectId)
        AlertDialog.Builder(this)
            .setTitle("AI Presenter Request तैयार")
            .setMessage("Project request तैयार है.\n\nEngine: $selectedEngine\nOutput: MP4\nFace motion: natural lips + eyes + blink + jaw + head + expression\nFile: ${file.name}")
            .setPositiveButton("ठीक है", null)
            .show()
        return file
    }

    private fun exportRequestPackage() {
        val file = buildRequestPackage() ?: return
        startActivityForResult(
            Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, file.name)
            }, 705
        )
    }

    private fun showMotionPreview(image: ImageView) {
        val p = ProjectStore.find(this, projectId)
        if (p?.presenterImage.isNullOrBlank()) {
            toast("पहले Master Presenter Photo चुनें"); return
        }
        if (previewRunning) {
            previewRunning = false
            image.animate().cancel()
            toast("Motion preview रोक दिया")
            return
        }
        previewRunning = true
        image.scaleX = 1f
        image.scaleY = 1f
        image.translationX = 0f
        image.animate()
            .scaleX(1.035f).scaleY(1.035f).translationX(dp(5).toFloat())
            .setDuration(850)
            .withEndAction {
                if (previewRunning) image.animate()
                    .scaleX(0.99f).scaleY(0.99f).translationX(dp(-4).toFloat())
                    .setDuration(650)
                    .withEndAction {
                        previewRunning = false
                        image.animate().scaleX(1f).scaleY(1f).translationX(0f).setDuration(350).start()
                    }.start()
            }.start()
        toast("Natural motion concept preview चल रहा है")
    }

    private fun showProductionPreview() {
        val p = ProjectStore.find(this, projectId)
        if (p == null) return
        val ready = listOf(
            !p.presenterImage.isBlank(),
            !p.script.isBlank(),
            !p.narrationAudio.isBlank(),
            !p.expressionPlan.isBlank(),
            !p.format.isBlank()
        ).count { it }
        val msg = """
Presenter: ${p.presenterType}
Headline: ${p.headline.ifBlank { "—" }}
Format: ${p.format}
Duration: ${p.duration} मिनट
Voice: ${p.voiceProfile}

Readiness: $ready / 5

Expression:
${if (p.expressionPlan.isBlank()) "Expression plan बाकी है." else p.expressionPlan.take(1000)}

Engine:
$selectedEngine

Output target:
MP4 • natural lips + eyes/blink + jaw + head motion + story-aware expression

External AI model:
अभी provider adapter के माध्यम से जोड़ना बाकी है.
        """.trimIndent()
        AlertDialog.Builder(this)
            .setTitle("Presenter Production Preview")
            .setMessage(msg)
            .setPositiveButton("ठीक है", null)
            .show()
    }

    private fun detectTone(text: String): String {
        val t = text.lowercase(Locale.getDefault())
        return when {
            listOf("ब्रेकिंग","तत्काल","breaking","urgent").any { t.contains(it) } -> "Breaking / Urgent"
            listOf("हत्या","मौत","दुर्घटना","crime","murder","death","आरोप").any { t.contains(it) } -> "Serious / Sensitive"
            listOf("जीत","सफलता","उपलब्धि","बधाई","success").any { t.contains(it) } -> "Positive / Good News"
            else -> "Neutral / General"
        }
    }

    private fun buildExpressionPlan(text: String): String {
        if (text.isBlank()) return ""
        val tone = detectTone(text)
        return when (tone) {
            "Breaking / Urgent" -> "Opening: alert + focused • Key facts: serious/attentive • Critical lines: concerned • Closing: composed newsroom neutral • Avoid smiling"
            "Serious / Sensitive" -> "Opening: calm + serious • Sensitive facts: concerned/empathetic • Details: restrained neutral • Closing: composed • Avoid exaggerated emotion"
            "Positive / Good News" -> "Opening: confident • Main result: warm professional • Key achievement: light positive expression • Closing: calm"
            else -> "Opening: neutral attentive • Key facts: focused • Transitions: natural blink + subtle head movement • Closing: composed professional"
        }
    }

    private fun checkCard(icon: String, title: String, ready: Boolean, note: String = "") =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = fieldBackground()
            addView(TextView(this@PresenterEngineActivity).apply {
                text = if (ready) "✓" else icon
                textSize = 15f
                setTextColor(if (ready) gold else muted)
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(32), dp(42)))
            addView(TextView(this@PresenterEngineActivity).apply {
                text = if (note.isBlank()) title else "$title\n$note"
                textSize = 12.5f
                setTextColor(if (ready) white else muted)
                gravity = Gravity.CENTER_VERTICAL
            }, LinearLayout.LayoutParams(0, dp(42), 1f))
        }.apply { layoutParams = lp(0,0,0,6) }

    private fun infoCard(title: String, value: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(11), dp(14), dp(11))
        background = fieldBackground()
        addView(TextView(this@PresenterEngineActivity).apply {
            text = title
            textSize = 9.5f
            setTextColor(gold)
        })
        addView(TextView(this@PresenterEngineActivity).apply {
            text = value
            textSize = 13f
            setTextColor(white)
            setPadding(0, dp(4), 0, 0)
        })
        layoutParams = lp(0,0,0,7)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(gold)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(7))
    }

    private fun choice(current: String) = TextView(this).apply {
        text = current
        textSize = 14f
        setTextColor(white)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), 0, dp(14), 0)
        background = fieldBackground()
        minimumHeight = dp(50)
    }

    private fun choose(options: List<String>, result: (String) -> Unit) {
        AlertDialog.Builder(this).setTitle("Engine चुनें")
            .setItems(options.toTypedArray()) { _, which -> result(options[which]) }
            .show()
    }

    private fun actionButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 13f
        isAllCaps = false
        setTextColor(white)
        typeface = Typeface.DEFAULT_BOLD
        background = buttonBackground()
        minimumHeight = dp(50)
        setOnClickListener { click() }
    }

    private fun buttonBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(39,34,23), Color.rgb(20,20,20))
    ).apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), gold) }

    private fun fieldBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(22,22,22), Color.rgb(14,14,14))
    ).apply { cornerRadius = dp(13).toFloat(); setStroke(dp(1), Color.rgb(64,58,42)) }

    private fun lp(l:Int,t:Int,r:Int,b:Int) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(l),dp(t),dp(r),dp(b))
        }

    private fun dp(v:Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s:String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        previewRunning = false
        handler.removeCallbacksAndMessages(null)
        if (isRecording) {
            try { recorder?.stop() } catch (_: Exception) {}
            recorder?.release()
            recorder = null
        }
        super.onDestroy()
    }
}

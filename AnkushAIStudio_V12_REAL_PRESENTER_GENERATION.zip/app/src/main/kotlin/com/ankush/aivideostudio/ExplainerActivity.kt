package com.ankush.aivideostudio

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ExplainerActivity : AppCompatActivity() {
    private val gold=Color.rgb(218,178,58)
    private val white=Color.rgb(245,244,240)
    private val muted=Color.rgb(174,174,174)
    private var format="16:9"
    private var style="Editorial Documentary"
    private var plan=mutableListOf<String>()
    private var projectId=""
    private var scriptValue=""

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        projectId=intent.getStringExtra("projectId") ?: ""
        loadProject()
        showEditor()
    }

    override fun onPause(){ autoSave(); super.onPause() }

    private fun loadProject(){
        if(projectId.isNotBlank()){
            ProjectStore.find(this,projectId)?.let{
                scriptValue=it.script
                format=it.format
            }
        }
    }

    private fun autoSave(){
        if(scriptValue.isBlank()) return
        projectId=ProjectStore.save(this,SavedProject(
            projectId,4,"Editorial Explainer",projectHeadline(), "5", scriptValue, format, emptyList(), 0L
        ))
    }

    private fun projectHeadline():String{
        val first=scriptValue.lines().firstOrNull{it.isNotBlank()}?.trim().orEmpty()
        return if(first.isBlank()) "Editorial Explainer Project" else first.take(80)
    }

    private fun showEditor(){
        val scroll=ScrollView(this).apply{
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(5,5,5),Color.rgb(18,15,10),Color.rgb(4,4,4)))
            isFillViewport=true
        }
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(20),dp(18),dp(28))}
        scroll.addView(root)

        root.addView(TextView(this).apply{
            text="‹  वापस HOME";textSize=13f;setTextColor(gold);setPadding(0,0,0,dp(12));setOnClickListener{autoSave();finish()}
        })
        root.addView(TextView(this).apply{
            text="🎞  EDITORIAL EXPLAINER";textSize=25f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER
        },lp(0,0,0,4))
        root.addView(TextView(this).apply{
            text="Story  →  Scenes  →  Visuals  →  Motion  →  Final Video";textSize=12.5f;setTextColor(muted);gravity=Gravity.CENTER
        },lp(0,0,0,10))
        root.addView(TextView(this).apply{
            text=if(projectId.isBlank())"●  नया project  •  Auto-save तैयार" else "✓  Project auto-save active"
            textSize=10.5f;setTextColor(gold);gravity=Gravity.CENTER
        },lp(0,0,0,14))

        val script=EditText(this).apply{
            hint="अपनी कहानी / स्क्रिप्ट यहाँ लिखें…";minLines=9;gravity=Gravity.TOP
            setText(scriptValue);setTextColor(white);setHintTextColor(Color.rgb(120,120,120));textSize=14f
            background=fieldBackground();setPadding(dp(14),dp(12),dp(14),dp(12))
        }
        root.addView(script,lp(0,0,0,16))
        script.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){scriptValue=script.text.toString();autoSave()}
            override fun afterTextChanged(s:android.text.Editable?){}
        })

        root.addView(label("INPUT MODE"))
        root.addView(choice("Script",listOf("Script","Recorded Voice (future transcription)","Script + Recorded Voice")),lp(0,0,0,12))
        root.addView(label("VISUAL STYLE"))
        root.addView(choice(style,listOf("Editorial Documentary","Paper Collage","2D Illustrated","Historical Archive","Cinematic Story","Map + Timeline","Infographic")).apply{
            setOnClickListener{choose(listOf("Editorial Documentary","Paper Collage","2D Illustrated","Historical Archive","Cinematic Story","Map + Timeline","Infographic")){style=it;text=it}}
        },lp(0,0,0,12))

        root.addView(label("AUTO INTELLIGENCE"))
        listOf("Auto scene / beat detection","Auto visual matching","Auto map & timeline when relevant","Auto captions / key words","Auto motion / pan / zoom","Auto background music & SFX").forEach{t->
            root.addView(CheckBox(this).apply{text=t;isChecked=true;setTextColor(white);buttonTintList=android.content.res.ColorStateList.valueOf(gold)})
        }
        root.addView(label("VIDEO FORMAT"))
        root.addView(choice("FORMAT  •  $format",listOf("16:9","9:16")).apply{
            setOnClickListener{choose(listOf("16:9","9:16")){format=it;text="FORMAT  •  $it";autoSave()}}
        },lp(0,0,0,14))

        root.addView(button("💾  SAVE PROJECT"){autoSave();toast("Editorial project सेव हो गया")})
        root.addView(button("🧩  BUILD AUTO SCENE PLAN"){buildPlan(script.text.toString())})
        root.addView(button("👁  PREVIEW SCENE PLAN"){showPlanDialog()})
        root.addView(button("🚀  PREPARE FOR AI GENERATION"){
            if(plan.isEmpty()) buildPlan(script.text.toString(),false)
            autoSave()
            AlertDialog.Builder(this).setTitle("AI Generation Ready")
                .setMessage("Scene plan तैयार है: ${plan.size} scene(s)\nStyle: $style\nFormat: $format\n\nAI image/video, voice, lip-sync और final rendering बाद में provider/API adapter से जोड़े जाएंगे.")
                .setPositiveButton("ठीक है",null).show()
        })
        root.addView(TextView(this).apply{
            text="✓ Auto-save active • फोन/Back interruption के बाद project सुरक्षित रहेगा"
            textSize=11f;setTextColor(muted);setPadding(dp(4),dp(14),dp(4),0)
        })
        setContentView(scroll)
    }

    private fun buildPlan(raw:String,show:Boolean=true){
        plan=raw.split(Regex("(?<=[.!?।])\\s+|\\n+")).map{it.trim()}.filter{it.isNotBlank()}.take(30).toMutableList()
        if(plan.isEmpty()) plan=mutableListOf("Scene 1 — पहले अपनी story/script लिखें।")
        if(show)showPlanDialog()
    }

    private fun showPlanDialog(){
        val text=if(plan.isEmpty()) "अभी scene plan नहीं बना है।" else plan.mapIndexed{i,s->"SCENE ${i+1}\n$s\nVisual: $style\nDuration: auto"}.joinToString("\n\n")
        AlertDialog.Builder(this).setTitle("Auto Scene Plan").setMessage(text).setPositiveButton("ठीक है",null).show()
    }

    private fun button(t:String,click:()->Unit)=Button(this).apply{
        text=t;textSize=13.5f;isAllCaps=false;setTextColor(white);typeface=Typeface.DEFAULT_BOLD
        background=buttonBackground();minimumHeight=dp(50);setOnClickListener{click()}
    }
    private fun label(t:String)=TextView(this).apply{text=t;textSize=11f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(4),0,dp(7))}
    private fun choice(current:String,options:List<String>)=TextView(this).apply{text=current;textSize=14f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(14),0);background=fieldBackground();minimumHeight=dp(50);setOnClickListener{choose(options){text=it}}}
    private fun choose(options:List<String>,result:(String)->Unit){AlertDialog.Builder(this).setTitle("चयन करें").setItems(options.toTypedArray()){_,i->result(options[i])}.show()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun fieldBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(22,22,22),Color.rgb(14,14,14))).apply{cornerRadius=dp(13).toFloat();setStroke(dp(1),Color.rgb(64,58,42))}
    private fun buttonBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(39,34,23),Color.rgb(20,20,20))).apply{cornerRadius=dp(14).toFloat();setStroke(dp(1),gold)}
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(l),dp(t),dp(r),dp(b))}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}

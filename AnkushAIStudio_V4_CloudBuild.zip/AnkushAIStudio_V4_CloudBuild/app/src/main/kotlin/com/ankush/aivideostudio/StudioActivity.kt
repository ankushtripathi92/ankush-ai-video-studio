package com.ankush.aivideostudio
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class StudioActivity:AppCompatActivity(){override fun onCreate(x:Bundle?){super.onCreate(x);val s=intent.getStringExtra("studio")?:"Studio";val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,22,18,18);setBackgroundColor(Color.rgb(8,8,8))};r.addView(TextView(this).apply{text=s;textSize=24f;setTextColor(Color.WHITE);setPadding(10,10,10,10)});listOf("🎬 FULL PRESENTER","🎙️ INTERVIEW / EXPERT MODE","👩 ANCHOR / CHARACTER LIBRARY","🖼️ PHOTOS / VIDEOS / SCREENSHOTS","📝 SCRIPT","🎙️ VOICE / VOICE CLONE","📐 16:9 / 9:16","▶️ PREVIEW / GENERATE").forEach{r.addView(Button(this).apply{text=it})};setContentView(r)}}

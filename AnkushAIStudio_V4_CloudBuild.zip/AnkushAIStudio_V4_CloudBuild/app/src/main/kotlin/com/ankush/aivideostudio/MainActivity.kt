package com.ankush.aivideostudio
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity:AppCompatActivity(){
 private fun b(s:String, f:()->Unit)=Button(this).apply{text=s;setOnClickListener{f()}}
 override fun onCreate(x:Bundle?){super.onCreate(x);val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,24,20,20);setBackgroundColor(Color.rgb(8,8,8))};
 val h=TextView(this).apply{text="ANKUSH AI VIDEO STUDIO";textSize=25f;setTextColor(Color.WHITE);setPadding(10,10,10,10)};r.addView(h)
 r.addView(TextView(this).apply{text="चारों चैनलों + Editorial Explainer Studio";textSize=14f;setTextColor(Color.LTGRAY)})
 val ss=listOf("📰 चित्रकूट न्यूज़","🔱 वैदिक एवं तांत्रिक ज्ञान","📈 Buycryptohub","😂 Comedy Conversation")
 ss.forEach{n->r.addView(b("$n\nPresenter • Interview • Media • Script"){startActivity(Intent(this,StudioActivity::class.java).putExtra("studio",n))},LinearLayout.LayoutParams(-1,88))}
 r.addView(b("🎞️ EDITORIAL EXPLAINER\nStory / Voice → Auto Visual Documentary"){startActivity(Intent(this,ExplainerActivity::class.java))},LinearLayout.LayoutParams(-1,100))
 r.addView(TextView(this).apply{text="V4 • Editorial Explainer pipeline added\nAI provider is behind an adapter; no paid API is called automatically.";textSize=13f;setTextColor(Color.GRAY);setPadding(10,15,10,10)});setContentView(r)} }

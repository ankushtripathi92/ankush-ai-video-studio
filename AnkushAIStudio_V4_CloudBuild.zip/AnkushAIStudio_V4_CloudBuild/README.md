# Ankush AI Video Studio V4
Five studios, including Editorial Explainer.

Editorial Explainer pipeline: story/script or recorded narration -> beat detection -> visual matching -> editorial/paper-collage/2D/historical/cinematic styles -> maps/timelines/infographics -> motion -> captions -> music/SFX -> scene stitching.

V4 contains the Android app-side workflow and planning layer. Actual AI generation is intentionally behind an AI Engine Adapter and is not called automatically.

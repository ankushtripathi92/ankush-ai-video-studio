package com.ankush.aivideostudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min

data class GeminiVideoResult(
    val interactionId: String,
    val status: String,
    val outputUri: String = "",
    val inlineBase64: String = "",
    val raw: String = ""
)

object GeminiOmniClient {
    private const val PREFS = "ankush_gemini_v17"
    private const val KEY = "api_key"
    private const val MODEL = "gemini-omni-1.1-flash"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private const val MAX_IMAGE_BYTES = 3_000_000

    fun load(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""

    fun save(context: Context, apiKey: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, apiKey.trim()).apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    fun testConnection(context: Context): String {
        val key = load(context)
        require(key.startsWith("AIza")) { "Google AI API key सेट करें" }
        val conn = open("$BASE/models/$MODEL", key, "GET")
        val body = readBody(conn)
        if (conn.responseCode !in 200..299) {
            throw IllegalStateException("Google AI HTTP ${conn.responseCode}: ${body.take(600)}")
        }
        return JSONObject(body).optString("name", MODEL)
    }

    fun submit(
        context: Context,
        project: SavedProject,
        performancePrompt: String
    ): GeminiVideoResult {
        val key = load(context)
        require(key.startsWith("AIza")) { "Google AI API key सेट करें" }
        require(project.presenterImage.isNotBlank()) { "Master Presenter Photo चुनें" }
        require(project.script.isNotBlank()) { "Presenter script डालें" }

        val imageB64 = imageBase64(context, Uri.parse(project.presenterImage))
        val prompt = performancePrompt.ifBlank {
            defaultPrompt(project)
        }

        val input = JSONArray()
            .put(JSONObject().apply {
                put("type", "image")
                put("data", imageB64)
                put("mime_type", "image/jpeg")
            })
            .put(JSONObject().apply {
                put("type", "text")
                put("text", prompt)
            })

        val generationConfig = JSONObject().apply {
            put("video_config", JSONObject().apply {
                put("task", "image_to_video")
            })
        }

        val responseFormat = JSONObject().apply {
            put("type", "video")
            put("aspect_ratio", if (project.format == "9:16") "9:16" else "16:9")
            put("resolution", "720p")
        }

        val payload = JSONObject().apply {
            put("model", MODEL)
            put("input", input)
            put("generation_config", generationConfig)
            put("response_format", responseFormat)
        }

        val conn = open("$BASE/interactions", key, "POST")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

        val body = readBody(conn)
        if (conn.responseCode !in 200..299) {
            throw IllegalStateException("Google AI HTTP ${conn.responseCode}: ${body.take(900)}")
        }

        val obj = JSONObject(body)
        val interactionId = obj.optString("id", "")
        val status = obj.optString("status", "unknown")
        var outputUri = ""
        var inline = ""

        val outputVideo = obj.optJSONObject("output_video")
        if (outputVideo != null) {
            outputUri = outputVideo.optString("uri", "")
            inline = outputVideo.optString("data", "")
        }

        val steps = obj.optJSONArray("steps")
        if (steps != null) {
            for (i in 0 until steps.length()) {
                val step = steps.optJSONObject(i) ?: continue
                val content = step.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val item = content.optJSONObject(j) ?: continue
                    if (item.optString("type") == "video") {
                        if (outputUri.isBlank()) outputUri = item.optString("uri", "")
                        if (inline.isBlank()) inline = item.optString("data", "")
                    }
                }
            }
        }

        return GeminiVideoResult(interactionId, status, outputUri, inline, body)
    }

    fun get(context: Context, interactionId: String): GeminiVideoResult {
        val key = load(context)
        require(key.startsWith("AIza")) { "Google AI API key सेट करें" }
        val conn = open("$BASE/interactions/$interactionId", key, "GET")
        val body = readBody(conn)
        if (conn.responseCode !in 200..299) {
            throw IllegalStateException("Google AI HTTP ${conn.responseCode}: ${body.take(700)}")
        }
        val obj = JSONObject(body)
        var outputUri = ""
        var inline = ""
        val outputVideo = obj.optJSONObject("output_video")
        if (outputVideo != null) {
            outputUri = outputVideo.optString("uri", "")
            inline = outputVideo.optString("data", "")
        }
        val steps = obj.optJSONArray("steps")
        if (steps != null) {
            for (i in 0 until steps.length()) {
                val step = steps.optJSONObject(i) ?: continue
                val content = step.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val item = content.optJSONObject(j) ?: continue
                    if (item.optString("type") == "video") {
                        if (outputUri.isBlank()) outputUri = item.optString("uri", "")
                        if (inline.isBlank()) inline = item.optString("data", "")
                    }
                }
            }
        }
        return GeminiVideoResult(
            obj.optString("id", interactionId),
            obj.optString("status", "unknown"),
            outputUri,
            inline,
            body
        )
    }

    fun downloadVideo(context: Context, result: GeminiVideoResult): Uri {
        val dir = File(context.filesDir, "generated_videos")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, "gemini_omni_${System.currentTimeMillis()}.mp4")

        if (result.inlineBase64.isNotBlank()) {
            file.writeBytes(Base64.decode(result.inlineBase64, Base64.DEFAULT))
        } else {
            require(result.outputUri.isNotBlank()) { "Google AI ने video output नहीं दिया" }
            val conn = (URL(result.outputUri).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 30_000
                readTimeout = 180_000
                setRequestProperty("x-goog-api-key", load(context))
            }
            if (conn.responseCode !in 200..299) {
                val body = readBody(conn)
                throw IllegalStateException("Google AI video download HTTP ${conn.responseCode}: ${body.take(500)}")
            }
            conn.inputStream.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            }
        }
        return Uri.fromFile(file)
    }

    private fun defaultPrompt(project: SavedProject): String {
        val tone = project.deliveryStyle.ifBlank { "Professional Newsroom" }
        return """
Create a photorealistic 8-second ${if (project.format == "9:16") "vertical" else "landscape"} video using the supplied image as the exact visual starting point.

The person in the image is a professional female Hindi news presenter speaking directly to the camera.
Preserve her identity, face, hairstyle, clothing, studio set, lighting, framing and background composition. Do not redesign, replace, crop, zoom, or change the newsroom set.

Animate a believable human speaking performance: natural lip and jaw articulation synchronized to the spoken Hindi words, subtle cheek and facial-muscle movement, natural blinking, tiny eye movements, gentle head motion, breathing and restrained shoulder/chest movement. Use occasional small conversational hand gestures only when they look physically natural and remain consistent with the original image. No exaggerated acting, no rubbery lips, no frozen face, no puppet-like motion.

The presenter should feel like a real television anchor sitting in the same studio, recorded by a real camera. Keep the camera mostly locked. Use ${tone.lowercase()} delivery.

She must speak this Hindi dialogue naturally and clearly:
"${project.script.trim()}"

Generate natural synchronized speech audio for the dialogue. Do not add extra words, narration, music or sound effects. Keep the original studio/background visually stable.
        """.trim()
    }

    private fun imageBase64(context: Context, uri: Uri): String {
        val original = openInput(context, uri)?.use { BitmapFactory.decodeStream(it) }
            ?: throw IllegalStateException("Master photo पढ़ी नहीं जा सकी")
        var bitmap = original
        try {
            var scale = min(1f, 1600f / max(bitmap.width, bitmap.height).toFloat())
            var bytes = ByteArray(0)
            repeat(7) {
                val w = max(1, (bitmap.width * scale).toInt())
                val h = max(1, (bitmap.height * scale).toInt())
                val scaled = if (w == bitmap.width && h == bitmap.height) bitmap else Bitmap.createScaledBitmap(bitmap, w, h, true)
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
                if (scaled !== bitmap) scaled.recycle()
                bytes = out.toByteArray()
                if (bytes.size <= MAX_IMAGE_BYTES) return@repeat
                scale *= 0.82f
            }
            if (bytes.isEmpty() || bytes.size > MAX_IMAGE_BYTES) {
                throw IllegalStateException("Master photo बहुत बड़ी है; छोटी साफ़ photo चुनें")
            }
            return Base64.encodeToString(bytes, Base64.NO_WRAP)
        } finally {
            original.recycle()
        }
    }

    private fun openInput(context: Context, uri: Uri): java.io.InputStream? {
        return if (uri.scheme.isNullOrBlank()) {
            val path = uri.path ?: return null
            FileInputStream(File(path))
        } else {
            context.contentResolver.openInputStream(uri)
        }
    }

    private fun open(url: String, key: String, method: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 30_000
            readTimeout = 180_000
            setRequestProperty("x-goog-api-key", key)
            setRequestProperty("Accept", "application/json")
        }

    private fun readBody(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        return stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
    }
}

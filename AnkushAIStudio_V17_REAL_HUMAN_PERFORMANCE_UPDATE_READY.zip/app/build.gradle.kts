plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ankush.aivideostudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ankush.aivideostudio"
        minSdk = 23
        targetSdk = 35
        versionCode = 17
        versionName = "17.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        create("release") {
            val signingFile = rootProject.file("signing/ankush-release.p12")
            val signingPassword = System.getenv("V17_SIGNING_PASSWORD") ?: ""
            if (signingFile.exists() && signingPassword.isNotBlank()) {
                storeFile = signingFile
                storePassword = signingPassword
                keyAlias = "ankush-release"
                keyPassword = signingPassword
                storeType = "PKCS12"
            }
        }
    }

    buildTypes {
        getByName("release") {
            val signingFile = rootProject.file("signing/ankush-release.p12")
            val signingPassword = System.getenv("V17_SIGNING_PASSWORD") ?: ""
            if (!signingFile.exists() || signingPassword.isBlank()) {
                throw GradleException("V17 permanent signing is not configured. Add GitHub secret V17_SIGNING_PASSWORD and decrypt signing/ankush-release.p12 before building.")
            }
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}

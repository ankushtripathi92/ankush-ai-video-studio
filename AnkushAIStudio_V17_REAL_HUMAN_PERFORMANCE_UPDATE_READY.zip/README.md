# Ankush AI Video Studio — V17

V17 is the first **Real Human Performance** release candidate built on the V16 foundation.

## V17 goals

- Google Gemini Omni Flash adapter for natural image-to-video presenter performance.
- Master presenter image + exact Hindi script → short photorealistic presenter clip with natively generated synchronized speech.
- Prompted natural mouth/jaw/cheek motion, blinking, eye focus, subtle head movement, breathing, shoulders/chest and restrained conversational hand gestures.
- Preserve the supplied newsroom composition/background as the visual starting point; avoid intentional redesign, crop or replacement.
- Keep the existing Replicate/SadTalker adapter as a fallback talking-head path.
- Generated MP4 persistence, video history and Gallery export remain.
- Existing projects and media data model remain compatible.
- **Permanent signing foundation:** V17 uses an encrypted release keystore in the package and a GitHub Actions secret to build a stable signed release. Once V17 is installed as the first permanent signed release, later versions can update it without uninstalling, provided the same signing key is retained.

## Important provider behavior

Google's current Gemini Omni Flash video API supports text + image inputs and generates video with audio. The current API does **not** accept an uploaded audio reference, so the V17 Gemini test uses the project script and lets Gemini generate synchronized speech. The existing ElevenLabs audio remains stored in the project and is still usable for the Replicate/SadTalker fallback.

## V17 test

Use:
- Master Presenter Photo
- Presenter script/dialogue
- 16:9 or 9:16
- `V17 REAL HUMAN TEST • GENERATE 8s PRESENTER`

The first target is an 8-second comparison against the user's YouTube Create reference clip.

## Permanent signing

The ZIP contains only an **encrypted** PKCS12 signing keystore:
`signing/ankush-release.p12.enc`

The plaintext keystore is never committed.

Before building the signed V17 release, add the GitHub Actions secret:

`V17_SIGNING_PASSWORD`

The password for the encrypted keystore is provided separately to the project owner and must never be committed to the repository.

The workflow then decrypts the keystore only inside the GitHub runner and builds:

`app-release.apk`

Do not change or replace the signing key after V17 is released. Losing the key prevents future Android updates over the installed V17 app.

## Build

The included workflow:
- extracts `AnkushAIStudio_V17_REAL_HUMAN_PERFORMANCE_UPDATE_READY.zip`
- decrypts the encrypted signing keystore using the GitHub secret
- runs `gradle assembleRelease`
- uploads `AnkushAIStudio-V17-signed-release-apk`

Line 7 of the workflow must contain only the ZIP filename.

Line 42 must contain:

`unzip -q AnkushAIStudio_V17_REAL_HUMAN_PERFORMANCE_UPDATE_READY.zip -d project`

## Security

Never paste Google AI API keys, Replicate tokens or the signing password into chat, screenshots, public GitHub files, or source code.

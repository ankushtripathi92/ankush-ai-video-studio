# Ankush AI Video Studio V2

V2 is a functional local foundation for four studios:
- Chitrakoot News
- Vaidik & Tantrik Gyan
- Buycryptohub
- Comedy Conversation

This version adds working navigation, script editing/saving, phone media selection, anchor/character selection, voice profile selection, aspect-ratio selection, presenter/interview setup, and project preview/save.

AI avatar, lip-sync, voice cloning API, cloud rendering, and final video generation are intentionally kept behind an AI Engine adapter for the next phase. No paid AI API is called by this V2 APK.

## Cloud build
The GitHub Actions workflow can build a debug APK from the ZIP at repository root.

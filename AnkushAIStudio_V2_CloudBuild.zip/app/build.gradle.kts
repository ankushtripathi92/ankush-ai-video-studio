plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ankush.aivideostudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ankush.aivideostudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}

kotlin {
    jvmToolchain(17)
}

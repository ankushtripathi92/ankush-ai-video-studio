# Ankush AI Video Studio — V5 Premium UI

V5 is the premium UI foundation based on the successful V4 Java 17/Kotlin 17 build.

Studios:
1. Chitrakoot News
2. Vaidik & Tantrik Gyan
3. Buycryptohub
4. Comedy Conversation
5. Editorial Explainer
6. Horror Story Studio

Design goals:
- Deep black / charcoal background
- Royal gold accents
- Soft white typography
- Rounded premium cards and controls
- More breathing room below status bar
- Consistent UI across Home and internal studios
- Dark dropdown/input controls with readable text

Important:
- Java source/target = 17
- Kotlin JVM target = 17
- Kotlin JVM toolchain = 17
- No paid AI API is called automatically
- AI Engine remains the next integration stage

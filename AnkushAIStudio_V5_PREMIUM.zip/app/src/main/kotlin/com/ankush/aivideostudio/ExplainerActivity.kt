package com.ankush.aivideostudio

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ExplainerActivity : AppCompatActivity() {
    private val gold=Color.rgb(212,175,55); private val white=Color.rgb(242,242,242); private val muted=Color.rgb(165,165,165)
    override fun onCreate(savedInstanceState: Bundle?){super.onCreate(savedInstanceState)
        val scroll=ScrollView(this).apply{setBackgroundColor(Color.rgb(7,7,7));isFillViewport=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,34,18,28)};scroll.addView(root)
        root.addView(TextView(this).apply{text="🎞️  EDITORIAL EXPLAINER";textSize=24f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER},lp(0,0,0,5))
        root.addView(TextView(this).apply{text="Story → Scenes → Visuals → Motion → Final Video";textSize=13f;setTextColor(white);gravity=Gravity.CENTER},lp(0,0,0,20))
        val script=EditText(this).apply{hint="अपनी कहानी / स्क्रिप्ट यहाँ लिखें…";minLines=8;gravity=48;setTextColor(white);setHintTextColor(Color.rgb(115,115,115));backgroundResource=R.drawable.premium_input}
        root.addView(script,lp(0,0,0,18))
        root.addView(section("INPUT MODE"))
        val input=choice("Script", listOf("Script","Recorded Voice (future AI transcription)","Script + Recorded Voice"));root.addView(input,lp(0,0,0,14))
        root.addView(section("VISUAL STYLE"))
        val style=choice("Editorial Documentary",listOf("Editorial Documentary","Paper Collage","2D Illustrated","Historical Archive","Cinematic Story","Map + Timeline","Infographic"));root.addView(style,lp(0,0,0,14))
        root.addView(section("AUTO INTELLIGENCE"))
        listOf("Auto scene / beat detection","Auto image / illustration matching","Auto map & timeline when relevant","Auto captions / key words","Auto motion / pan / zoom","Auto background music & SFX").forEach{t->
            root.addView(CheckBox(this).apply{text=t;isChecked=true;setTextColor(white);buttonTintList=android.content.res.ColorStateList.valueOf(gold)},lp(0,0,0,2))
        }
        root.addView(section("FORMAT"));root.addView(choice("16:9",listOf("16:9","9:16")),lp(0,0,0,14))
        root.addView(section("VISUAL DENSITY"));root.addView(choice("Balanced",listOf("Balanced","Low","High")),lp(0,0,0,18))
        root.addView(action("🧩  BUILD AUTO SCENE PLAN")){ }
        root.addView(action("👁  PREVIEW SCENE PLAN")){ }
        root.addView(action("🚀  PREPARE FOR AI GENERATION")){ }
        root.addView(TextView(this).apply{text="V5 note: यह foundation किसी paid AI API को स्वतः call नहीं करता। AI image/video, voice, lip-sync और rendering आगे adapter layer से जुड़ेंगे।";textSize=11.5f;setTextColor(muted);setPadding(4,16,4,0)})
        setContentView(scroll)
    }
    private fun section(s:String)=TextView(this).apply{text=s;textSize=12f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;setPadding(2,4,0,8)}
    private fun choice(current:String,options:List<String>):TextView=TextView(this).apply{ text=current; textSize=15f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(16,0,16,0);backgroundResource=R.drawable.premium_input;setOnClickListener{AlertDialog.Builder(this@ExplainerActivity).setTitle("चयन करें").setItems(options.toTypedArray()){_,w->text=options[w]}.show()}}
    private fun action(label:String)=Button(this).apply{text=label;textSize=14f;isAllCaps=false;setTextColor(white);backgroundResource=R.drawable.premium_button;setOnClickListener{Toast.makeText(this@ExplainerActivity,"V5 foundation: अगले चरण में AI Engine जोड़ा जाएगा।",Toast.LENGTH_SHORT).show()}}
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(l,t,r,b)}
}

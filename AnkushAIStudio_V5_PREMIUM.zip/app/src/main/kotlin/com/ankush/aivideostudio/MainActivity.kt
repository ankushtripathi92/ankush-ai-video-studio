package com.ankush.aivideostudio

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(7, 7, 7)
    private val gold = Color.rgb(212, 175, 55)
    private val white = Color.rgb(242, 242, 242)
    private val muted = Color.rgb(166, 166, 166)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 34, 20, 28) }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "ANKUSH AI VIDEO STUDIO"; textSize = 27f; setTextColor(gold)
            typeface = Typeface.create("sans-serif", Typeface.BOLD); gravity = Gravity.CENTER; letterSpacing = .035f
        }, lp(0,0,0,6))
        root.addView(TextView(this).apply {
            text = "आपका निजी AI वीडियो प्रोडक्शन स्टूडियो"; textSize = 16f; setTextColor(white); gravity = Gravity.CENTER
        }, lp(0,0,0,4))
        root.addView(TextView(this).apply {
            text = "NEWS  •  SPIRITUAL  •  FINANCE  •  COMEDY  •  DOCUMENTARY  •  HORROR"
            textSize = 9.5f; setTextColor(gold); gravity = Gravity.CENTER
        }, lp(0,0,0,22))

        val studios = listOf(
            arrayOf("📰", "चित्रकूट न्यूज़", "News Presenter • Interview • Guest"),
            arrayOf("🔱", "वैदिक एवं तांत्रिक ज्ञान", "Presenter • प्रश्न–उत्तर • Podcast"),
            arrayOf("📈", "Buycryptohub", "Stock • Crypto • Split Screen"),
            arrayOf("😂", "Comedy Conversation", "Character 1 • Character 2 • Dialogue"),
            arrayOf("🎞️", "Editorial Explainer", "Story → Scenes → Visuals → Motion"),
            arrayOf("👻", "Horror Story Studio", "Scenes • Characters • Dialogue • Atmosphere")
        )
        studios.forEachIndexed { index, item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.premium_card); elevation = 3f; isClickable = true
                setOnClickListener {
                    when (index) {
                        4 -> startActivity(Intent(this@MainActivity, ExplainerActivity::class.java))
                        5 -> startActivity(Intent(this@MainActivity, HorrorActivity::class.java))
                        else -> startActivity(Intent(this@MainActivity, StudioActivity::class.java).apply {
                            putExtra("studioIndex", index); putExtra("studioName", item[1])
                        })
                    }
                }
            }
            card.addView(TextView(this).apply { text = item[0]; textSize = 28f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(52, 64))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            info.addView(TextView(this).apply { text = item[1]; textSize = 17f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD })
            info.addView(TextView(this).apply { text = item[2]; textSize = 12.5f; setTextColor(muted); setPadding(0,4,0,0) })
            card.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(TextView(this).apply { text = "›"; textSize = 28f; setTextColor(gold); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(32,64))
            root.addView(card, lp(0,0,0,12))
        }
        root.addView(TextView(this).apply {
            text = "✦  V5 PREMIUM FOUNDATION  •  AI ENGINE ADAPTER READY"; textSize = 12f; setTextColor(gold); gravity = Gravity.CENTER; setPadding(0,16,0,5)
        })
        root.addView(TextView(this).apply {
            text = "AI generation, voice, avatar, lip-sync और final rendering को provider/API layer में जोड़ा जाएगा।"
            textSize = 11.5f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(8,0,8,0)
        })
        setContentView(scroll)
    }
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(l,t,r,b)}
}

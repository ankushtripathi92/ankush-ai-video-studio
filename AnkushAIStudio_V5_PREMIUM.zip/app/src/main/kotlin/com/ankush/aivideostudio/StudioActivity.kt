package com.ankush.aivideostudio

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class StudioActivity : AppCompatActivity() {
    private val gold=Color.rgb(212,175,55); private val white=Color.rgb(242,242,242); private val muted=Color.rgb(165,165,165)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        val name=intent.getStringExtra("studioName") ?: "STUDIO"
        val scroll=ScrollView(this).apply{setBackgroundColor(Color.rgb(7,7,7));isFillViewport=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,34,20,28)};scroll.addView(root)
        root.addView(TextView(this).apply{text="‹  वापस STUDIO";textSize=13f;setTextColor(gold);setPadding(0,0,0,14)})
        root.addView(TextView(this).apply{text=name;textSize=25f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER},lp(0,0,0,5))
        root.addView(TextView(this).apply{text="Professional Studio Workspace";textSize=13f;setTextColor(muted);gravity=Gravity.CENTER},lp(0,0,0,22))
        val items=listOf("🎬  FULL PRESENTER","🎙️  INTERVIEW / EXPERT MODE","👤  ANCHOR / CHARACTER LIBRARY","🖼️  PHOTOS / VIDEOS / MEDIA","📝  SCRIPT / VOICE","📐  16:9 / 9:16","▶  PREVIEW / GENERATE")
        items.forEach{label->
            val card=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(16,14,12,14);setBackgroundResource(R.drawable.premium_card);setOnClickListener{Toast.makeText(this@StudioActivity,"V5 foundation: AI generation layer अगले चरण में",Toast.LENGTH_SHORT).show()}}
            card.addView(TextView(this).apply{text=label;textSize=16f;setTextColor(white);typeface=Typeface.DEFAULT_BOLD},LinearLayout.LayoutParams(0,56,1f))
            card.addView(TextView(this).apply{text="›";textSize=25f;setTextColor(gold);gravity=Gravity.CENTER},LinearLayout.LayoutParams(28,56))
            root.addView(card,lp(0,0,0,11))
        }
        setContentView(scroll)
    }
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(l,t,r,b)}
}

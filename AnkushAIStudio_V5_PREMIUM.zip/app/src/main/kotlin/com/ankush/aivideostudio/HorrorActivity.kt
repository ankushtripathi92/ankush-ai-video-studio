package com.ankush.aivideostudio

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class HorrorActivity : AppCompatActivity() {
    private val gold=Color.rgb(212,175,55); private val white=Color.rgb(242,242,242); private val muted=Color.rgb(165,165,165)
    override fun onCreate(savedInstanceState: Bundle?){super.onCreate(savedInstanceState)
        val scroll=ScrollView(this).apply{setBackgroundColor(Color.rgb(7,7,7));isFillViewport=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,34,18,28)};scroll.addView(root)
        root.addView(TextView(this).apply{text="👻  HORROR STORY STUDIO";textSize=24f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER},lp(0,0,0,5))
        root.addView(TextView(this).apply{text="Scenes → Characters → Dialogue → Atmosphere → Final Video";textSize=12.5f;setTextColor(white);gravity=Gravity.CENTER},lp(0,0,0,20))
        root.addView(EditText(this).apply{hint="हॉरर कहानी / स्क्रिप्ट यहाँ लिखें…";minLines=7;gravity=48;setTextColor(white);setHintTextColor(Color.rgb(115,115,115));backgroundResource=R.drawable.premium_input},lp(0,0,0,18))
        root.addView(section("INPUT"))
        root.addView(choice("Script + Scene Images",listOf("Script + Scene Images","Recorded Voice + Scene Images","Script + Voice + Scene Images")),lp(0,0,0,14))
        root.addView(section("ANIMATION STYLE"))
        root.addView(choice("Cinematic 2D",listOf("Cinematic 2D","3D Horror","Dark Cartoon","Paper / Illustrated","Cinematic Realistic")),lp(0,0,0,14))
        root.addView(section("CHARACTER & DIALOGUE"))
        listOf("Use scene images in supplied order","Detect character names from scene labels","Pause narration during character dialogue","Resume narration after dialogue","Allow different voices for characters").forEach{t->root.addView(CheckBox(this).apply{text=t;isChecked=true;setTextColor(white);buttonTintList=android.content.res.ColorStateList.valueOf(gold)})}
        root.addView(section("FORMAT"));root.addView(choice("16:9",listOf("16:9","9:16")),lp(0,0,0,18))
        root.addView(action("🧩  BUILD HORROR SCENE PLAN"));root.addView(action("👁  PREVIEW SCENES"));root.addView(action("🚀  PREPARE FOR AI GENERATION"))
        root.addView(TextView(this).apply{text="V5 foundation: user-supplied scene images और character dialogue workflow को आगे AI animation/voice/lip-sync adapter से जोड़ा जाएगा।";textSize=11.5f;setTextColor(muted);setPadding(4,16,4,0)})
        setContentView(scroll)
    }
    private fun section(s:String)=TextView(this).apply{text=s;textSize=12f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;setPadding(2,4,0,8)}
    private fun choice(current:String,options:List<String>)=TextView(this).apply{text=current;textSize=15f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(16,0,16,0);backgroundResource=R.drawable.premium_input;setOnClickListener{AlertDialog.Builder(this@HorrorActivity).setTitle("चयन करें").setItems(options.toTypedArray()){_,w->text=options[w]}.show()}}
    private fun action(label:String)=Button(this).apply{text=label;textSize=14f;isAllCaps=false;setTextColor(white);backgroundResource=R.drawable.premium_button;setOnClickListener{Toast.makeText(this@HorrorActivity,"Horror foundation तैयार है; AI Engine अगले चरण में।",Toast.LENGTH_SHORT).show()};layoutParams=lp(0,0,0,10)}
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(l,t,r,b)}
}

# Ankush AI Video Studio — V16

V16 is the working continuation of V15 Real Presenter Generation Engine.

## V16 focus
- Real presenter generation through the existing Replicate/SadTalker adapter.
- Full-image preprocessing to avoid the V15 crop problem.
- Restrained, professional newsroom motion.
- Generated MP4 persistence in the project instead of temporary cache storage.
- Generated Video Library with Play / Save-to-Gallery actions.
- One-level-at-a-time Studio Back navigation.
- Existing API token/provider configuration is preserved.
\## Presenter target
Master photo composition/background is treated as locked. The engine is configured for full-image animation, still mode, subtle expression, eye blink and restrained head motion. Exact 100% identity preservation cannot be guaranteed by an AI model, but the app's target is natural broadcast-style delivery without theatrical overacting.
\## Build
GitHub Actions extracts `AnkushAIStudio_V16_REAL_PRESENTER_COMPOSITION_LOCK.zip` and runs `gradle assembleDebug`.

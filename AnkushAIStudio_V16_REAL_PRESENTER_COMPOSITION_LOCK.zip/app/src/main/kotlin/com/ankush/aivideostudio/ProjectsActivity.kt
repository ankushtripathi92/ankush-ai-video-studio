package com.ankush.aivideostudio

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProjectsActivity : AppCompatActivity() {
    private val gold = Color.rgb(218,178,58)
    private val white = Color.rgb(245,244,240)
    private val muted = Color.rgb(174,174,174)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showProjects()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) showProjects()
    }

    private fun showProjects() {
        val scroll = ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5,5,5), Color.rgb(18,15,10), Color.rgb(4,4,4))
            )
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "‹  वापस HOME"
            textSize = 13f
            setTextColor(gold)
            setOnClickListener { finish() }
        }, lp(0,0,0,12))

        root.addView(TextView(this).apply {
            text = "MY PROJECTS"
            textSize = 27f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, lp(0,0,0,4))

        root.addView(TextView(this).apply {
            text = "आपके projects फोन में local रूप से सुरक्षित रहते हैं"
            textSize = 12.5f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }, lp(0,0,0,16))

        root.addView(button("＋  NEW PROJECT") { chooseStudioForNewProject() }, lp(0,0,0,16))

        val projects = ProjectStore.all(this)
        if (projects.isEmpty()) {
            root.addView(infoCard("अभी कोई project नहीं", "NEW PROJECT दबाकर पहला project शुरू करें।"))
        } else {
            projects.forEach { addProjectCard(it) }
        }

        root.addView(TextView(this).apply {
            text = "✓ Auto-save active  •  ऐप बंद/Back होने पर भी saved projects बने रहते हैं"
            textSize = 10.5f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })
        setContentView(scroll)
    }

    private fun addProjectCard(p: SavedProject) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(14), dp(15), dp(14))
            background = cardBackground()
        }
        card.addView(TextView(this).apply {
            text = if (p.headline.isBlank()) "Untitled Project" else p.headline
            textSize = 17f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        })
        card.addView(TextView(this).apply {
            text = "${p.studioName}  •  ${p.duration} मिनट  •  ${p.format}"
            textSize = 11.5f
            setTextColor(gold)
            setPadding(0, dp(5), 0, 0)
        })
        card.addView(TextView(this).apply {
            text = "Last saved: ${formatTime(p.updatedAt)}  •  ${p.mediaNames.size} media  •  ${p.generatedVideos.size} generated videos"
            textSize = 10.5f
            setTextColor(muted)
            setPadding(0, dp(3), 0, dp(10))
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        row.addView(smallButton("OPEN / EDIT") { openProject(p) }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(0,0,dp(5),0) })
        row.addView(smallButton("DUPLICATE") {
            ProjectStore.duplicate(this, p.id)
            showProjects()
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(5),0,dp(5),0) })
        row.addView(smallButton("DELETE") {
            AlertDialog.Builder(this).setTitle("Project delete करें?")
                .setMessage("यह project इस फोन से हट जाएगा।")
                .setNegativeButton("रद्द करें", null)
                .setPositiveButton("DELETE") { _, _ -> ProjectStore.delete(this, p.id); showProjects() }
                .show()
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(5),0,0,0) })
        card.addView(row)
        root.addView(card, lp(0,0,0,10))
    }

    private fun chooseStudioForNewProject() {
        val studios = arrayOf(
            "📰 चित्रकूट न्यूज़",
            "🔱 वैदिक एवं तांत्रिक ज्ञान",
            "📈 Buycryptohub",
            "😂 Comedy Conversation",
            "🎞 Editorial Explainer",
            "👻 Horror Story Studio"
        )
        AlertDialog.Builder(this).setTitle("किस Studio में project बनाना है?")
            .setItems(studios) { _, which -> launchStudio(which, "") }
            .show()
    }

    private fun openProject(p: SavedProject) = launchStudio(p.studioIndex, p.id)

    private fun launchStudio(index: Int, projectId: String) {
        val isNewProject = projectId.isBlank()
        when (index) {
            4 -> startActivity(android.content.Intent(this, ExplainerActivity::class.java).apply {
                putExtra("projectId", projectId)
                putExtra("newProject", isNewProject)
            })
            5 -> startActivity(android.content.Intent(this, HorrorActivity::class.java).apply {
                putExtra("projectId", projectId)
                putExtra("newProject", isNewProject)
            })
            else -> startActivity(android.content.Intent(this, StudioActivity::class.java).apply {
                putExtra("studioIndex", index)
                putExtra("studioName", studioName(index))
                putExtra("projectId", projectId)
                putExtra("newProject", isNewProject)
            })
        }
    }

    private fun studioName(index: Int) = when(index) {
        0 -> "चित्रकूट न्यूज़"
        1 -> "वैदिक एवं तांत्रिक ज्ञान"
        2 -> "Buycryptohub"
        3 -> "Comedy Conversation"
        4 -> "Editorial Explainer"
        else -> "Horror Story Studio"
    }

    private fun formatTime(ms: Long): String =
        if (ms <= 0) "अभी" else SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ms))

    private fun button(t:String, click:()->Unit) = Button(this).apply {
        text=t; textSize=13.5f; isAllCaps=false; setTextColor(white); typeface=Typeface.DEFAULT_BOLD
        background=buttonBackground(); minimumHeight=dp(50); setOnClickListener { click() }
    }

    private fun smallButton(t:String, click:()->Unit) = Button(this).apply {
        text=t; textSize=10.5f; isAllCaps=false; setTextColor(white); typeface=Typeface.DEFAULT_BOLD
        background=buttonBackground(); minimumHeight=dp(44); setOnClickListener { click() }
    }

    private fun infoCard(title:String,value:String)=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12)); background=fieldBackground()
        addView(TextView(this@ProjectsActivity).apply { text=title; textSize=12f; setTextColor(gold) })
        addView(TextView(this@ProjectsActivity).apply { text=value; textSize=13f; setTextColor(white); setPadding(0,dp(5),0,0) })
    }

    private fun cardBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(25,23,19),Color.rgb(13,13,13))).apply{cornerRadius=dp(18).toFloat();setStroke(dp(1),Color.rgb(106,85,34))}
    private fun buttonBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(39,34,23),Color.rgb(20,20,20))).apply{cornerRadius=dp(14).toFloat();setStroke(dp(1),gold)}
    private fun fieldBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(22,22,22),Color.rgb(14,14,14))).apply{cornerRadius=dp(13).toFloat();setStroke(dp(1),Color.rgb(64,58,42))}
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(l),dp(t),dp(r),dp(b))}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}

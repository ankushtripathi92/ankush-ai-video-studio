package com.ankush.aivideostudio

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * V16 generic HTTPS presenter-engine adapter.
 * The app sends a documented multipart request and accepts a small JSON job response.
 * A compatible server can be local/remote and may wrap SadTalker or another licensed engine.
 */
object PresenterApiClient {
    private const val PREFS = "ankush_presenter_api_v14"
    private const val ENDPOINT = "endpoint"
    private const val API_KEY = "apiKey"

    data class Config(val endpoint: String, val apiKey: String)
    data class SubmitResult(val jobId: String, val outputUrl: String = "", val raw: String = "")

    fun load(context: Context): Config {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Config(p.getString(ENDPOINT, "") ?: "", p.getString(API_KEY, "") ?: "")
    }

    fun save(context: Context, config: Config) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(ENDPOINT, config.endpoint.trim())
            .putString(API_KEY, config.apiKey.trim())
            .apply()
    }

    fun submit(context: Context, project: SavedProject, jobJson: String): SubmitResult {
        val cfg = load(context)
        require(cfg.endpoint.startsWith("https://")) { "HTTPS endpoint सेट करें" }
        val boundary = "----AnkushV16${UUID.randomUUID()}"
        val conn = (URL(cfg.endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 30_000
            readTimeout = 120_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            if (cfg.apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer ${cfg.apiKey}")
        }
        conn.outputStream.use { out ->
            fun field(name: String, value: String) {
                out.write(("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n").toByteArray(Charsets.UTF_8))
            }
            field("job", jobJson)
            writeUriPart(out, boundary, "presenter_image", "presenter.jpg", "image/jpeg", project.presenterImage, context)
            if (project.narrationAudio.isNotBlank()) {
                writeUriPart(out, boundary, "narration_audio", "narration.m4a", "audio/mp4", project.narrationAudio, context)
            }
            out.write(("--$boundary--\r\n").toByteArray(Charsets.UTF_8))
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() } } ?: ""
        if (code !in 200..299) throw IllegalStateException("HTTP $code: ${body.take(500)}")
        val obj = JSONObject(body)
        val jobId = obj.optString("jobId", obj.optString("id", ""))
        val outputUrl = obj.optString("outputUrl", obj.optString("videoUrl", ""))
        if (jobId.isBlank() && outputUrl.isBlank()) throw IllegalStateException("API response में jobId या outputUrl नहीं मिला")
        return SubmitResult(jobId.ifBlank { "completed" }, outputUrl, body)
    }

    fun downloadVideo(context: Context, urlString: String): Uri {
        require(urlString.startsWith("https://")) { "केवल HTTPS output URL स्वीकार है" }
        val conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
        }
        val code = conn.responseCode
        if (code !in 200..299) throw IllegalStateException("Video download HTTP $code")
        val dir = File(context.filesDir, "generated_videos")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, "presenter_${System.currentTimeMillis()}.mp4")
        BufferedInputStream(conn.inputStream).use { input -> file.outputStream().use { output -> input.copyTo(output) } }
        return Uri.fromFile(file)
    }

    private fun writeUriPart(
        out: java.io.OutputStream,
        boundary: String,
        fieldName: String,
        fileName: String,
        mime: String,
        uriString: String,
        context: Context
    ) {
        val uri = Uri.parse(uriString)
        val input = context.contentResolver.openInputStream(uri) ?: return
        out.write(("--$boundary\r\nContent-Disposition: form-data; name=\"$fieldName\"; filename=\"$fileName\"\r\nContent-Type: $mime\r\n\r\n").toByteArray(Charsets.UTF_8))
        input.use { it.copyTo(out) }
        out.write("\r\n".toByteArray())
    }
}

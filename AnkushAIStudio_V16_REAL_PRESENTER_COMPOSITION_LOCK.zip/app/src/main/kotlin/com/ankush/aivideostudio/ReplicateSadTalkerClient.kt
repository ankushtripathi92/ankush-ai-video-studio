package com.ankush.aivideostudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * V16 direct provider adapter for Replicate's public cjwbw/sadtalker model.
 *
 * The first V16 test intentionally uses small data URLs so the Android app does not
 * need a separate upload server. Replicate documents data URLs for small inputs.
 */
object ReplicateSadTalkerClient {
    private const val PREFS = "ankush_replicate_v15"
    private const val TOKEN = "token"
    private const val MODEL_VERSION = "cjwbw/sadtalker:a519cc0cfebaaeade068b23899165a11ec76aaa1d2b313d40d214f204ec957a3"
    private const val MAX_DATA_URL_BYTES = 250 * 1024
    private const val MAX_RAW_INPUT_BYTES = 175 * 1024

    data class Config(val token: String)
    data class Prediction(
        val id: String,
        val status: String,
        val outputUrl: String = "",
        val webUrl: String = "",
        val error: String = "",
        val raw: String = ""
    )

    fun load(context: Context): Config = Config(
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(TOKEN, "") ?: ""
    )

    fun save(context: Context, token: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(TOKEN, token.trim()).apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun modelVersion(): String = MODEL_VERSION

    fun testConnection(context: Context): String {
        val token = load(context).token
        require(token.startsWith("r8_")) { "Replicate API token सही नहीं दिख रहा। r8_ से शुरू होने वाला token डालें।" }
        val conn = open("https://api.replicate.com/v1/models/cjwbw/sadtalker", token, "GET")
        val body = readBody(conn)
        if (conn.responseCode !in 200..299) throw IllegalStateException("Replicate HTTP ${conn.responseCode}: ${body.take(300)}")
        val obj = JSONObject(body)
        return obj.optString("name", "sadtalker")
    }

    fun submit(context: Context, project: SavedProject): Prediction {
        val token = load(context).token
        require(token.startsWith("r8_")) { "पहले Replicate API token सेट करें" }
        require(project.presenterImage.isNotBlank()) { "Master Presenter Photo चुनें" }
        require(project.narrationAudio.isNotBlank()) { "पहले narration audio रिकॉर्ड/इम्पोर्ट करें" }

        val imageData = imageDataUrl(context, Uri.parse(project.presenterImage))
        val audioData = audioDataUrl(context, Uri.parse(project.narrationAudio))

        val expression = when (project.motionIntensity) {
            "Natural / Subtle" -> 0.85
            "Expressive / Strong" -> 1.25
            else -> 1.0
        }
        val still = project.motionIntensity == "Natural / Subtle"
        val input = JSONObject().apply {
            put("source_image", imageData)
            put("driven_audio", audioData)
            // V16: preserve the complete supplied composition/background.
            // SadTalker documents `full` + still mode for full-image animation.
            put("facerender", "pirender")
            put("pose_style", 0)
            put("preprocess", "full")
            put("still_mode", true)
            put("use_enhancer", true)
            put("use_eyeblink", true)
            put("size_of_image", 512)
            // Restrained newsroom movement: natural, not theatrical.
            put("expression_scale", minOf(0.90, expression))
        }
        val payload = JSONObject().apply {
            put("version", MODEL_VERSION)
            put("input", input)
        }

        val conn = open("https://api.replicate.com/v1/predictions", token, "POST")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Prefer", "wait=5")
        conn.doOutput = true
        conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        val body = readBody(conn)
        if (conn.responseCode !in 200..299) throw IllegalStateException("Replicate HTTP ${conn.responseCode}: ${body.take(600)}")
        return parsePrediction(body)
    }

    fun get(context: Context, predictionId: String): Prediction {
        val token = load(context).token
        require(token.startsWith("r8_")) { "Replicate API token सेट करें" }
        val conn = open("https://api.replicate.com/v1/predictions/$predictionId", token, "GET")
        val body = readBody(conn)
        if (conn.responseCode !in 200..299) throw IllegalStateException("Replicate HTTP ${conn.responseCode}: ${body.take(500)}")
        return parsePrediction(body)
    }

    fun cancel(context: Context, predictionId: String) {
        val token = load(context).token
        val conn = open("https://api.replicate.com/v1/predictions/$predictionId/cancel", token, "POST")
        conn.doOutput = true
        conn.outputStream.use { }
        val body = readBody(conn)
        if (conn.responseCode !in 200..299) throw IllegalStateException("Cancel HTTP ${conn.responseCode}: ${body.take(300)}")
    }

    private fun parsePrediction(body: String): Prediction {
        val obj = JSONObject(body)
        val output = obj.opt("output")
        var outputUrl = ""
        when (output) {
            is String -> outputUrl = output
            is JSONArray -> if (output.length() > 0) outputUrl = output.optString(0, "")
        }
        val error = when (val e = obj.opt("error")) {
            null, JSONObject.NULL -> ""
            else -> e.toString()
        }
        val urls = obj.optJSONObject("urls")
        return Prediction(
            id = obj.optString("id", ""),
            status = obj.optString("status", "unknown"),
            outputUrl = outputUrl,
            webUrl = urls?.optString("web", "") ?: "",
            error = error,
            raw = body
        )
    }

    private fun open(url: String, token: String, method: String): HttpURLConnection {
        return (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 30_000
            readTimeout = 120_000
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/json")
        }
    }

    private fun readBody(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        return stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
    }

    private fun imageDataUrl(context: Context, uri: Uri): String {
        val original = openInput(context, uri)?.use { BitmapFactory.decodeStream(it) }
            ?: throw IllegalStateException("Master photo पढ़ी नहीं जा सकी")
        var bitmap = original
        try {
            var scale = minOf(1f, 768f / maxOf(bitmap.width, bitmap.height).toFloat())
            var quality = 78
            var bytes = ByteArray(0)
            repeat(6) {
                val w = maxOf(1, (bitmap.width * scale).toInt())
                val h = maxOf(1, (bitmap.height * scale).toInt())
                val scaled = if (w == bitmap.width && h == bitmap.height) bitmap else Bitmap.createScaledBitmap(bitmap, w, h, true)
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
                if (scaled !== bitmap) scaled.recycle()
                bytes = out.toByteArray()
                if (bytes.size <= MAX_RAW_INPUT_BYTES) return@repeat
                quality -= 10
                scale *= 0.82f
            }
            if (bytes.isEmpty() || bytes.size > MAX_RAW_INPUT_BYTES) {
                throw IllegalStateException("Photo बहुत बड़ी है। V16 first test के लिए छोटी/साफ़ portrait photo चुनें।")
            }
            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val dataUrl = "data:image/jpeg;base64,$encoded"
            require(dataUrl.toByteArray(Charsets.UTF_8).size <= MAX_DATA_URL_BYTES) {
                "Photo data URL बहुत बड़ी है; छोटी photo चुनें।"
            }
            return dataUrl
        } finally {
            original.recycle()
        }
    }

    private fun openInput(context: Context, uri: Uri): java.io.InputStream? {
        return if (uri.scheme.isNullOrBlank()) {
            val path = uri.path ?: return null
            FileInputStream(File(path))
        } else {
            context.contentResolver.openInputStream(uri)
        }
    }

    private fun audioDataUrl(context: Context, uri: Uri): String {
        val bytes = openInput(context, uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Narration audio पढ़ी नहीं जा सकी")
        if (bytes.size > MAX_RAW_INPUT_BYTES) {
            throw IllegalStateException("Audio बहुत बड़ी है। V16 first test के लिए 30–60 सेकंड की narration रिकॉर्ड करें; रिकॉर्डिंग low-size mode में रहेगी।")
        }
        val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val dataUrl = "data:audio/mp4;base64,$encoded"
        require(dataUrl.toByteArray(Charsets.UTF_8).size <= MAX_DATA_URL_BYTES) {
            "Audio data URL बहुत बड़ी है; 30–60 सेकंड की छोटी test narration इस्तेमाल करें।"
        }
        return dataUrl
    }
}

# Ankush AI Video Studio — V14

## Real Presenter Engine Bridge

V14 advances the presenter workspace from a request-only foundation to an executable HTTPS engine adapter.

### Presenter pipeline
Master Presenter Photo + Script + Narration Audio + Story-aware Expression Plan + Performance Controls
→ V14 Presenter Job
→ HTTPS AI Engine Adapter
→ licensed facial-animation model/server
→ MP4
→ local project tracking + playback

### Adapter contract
The configured HTTPS endpoint receives `multipart/form-data` with:
- `job`: V14 JSON generation package
- `presenter_image`: master presenter image
- `narration_audio`: narration audio

The endpoint should return JSON containing:
- `jobId` or `id`
- optional immediate `outputUrl` or `videoUrl`

If an output URL is returned immediately, V14 downloads the MP4 and stores it with the project. For long-running providers, the returned job ID can be used by a future polling/status adapter.

### Security
- Endpoint must use HTTPS.
- Optional API key is sent as `Authorization: Bearer ...`.
- Do not put private API keys into source code.

### Important
V14 does not bundle a large AI model inside the APK. The actual talking-face/lip-sync rendering is performed by a compatible licensed model/server/provider. This keeps the Android app practical and allows future engine swaps.

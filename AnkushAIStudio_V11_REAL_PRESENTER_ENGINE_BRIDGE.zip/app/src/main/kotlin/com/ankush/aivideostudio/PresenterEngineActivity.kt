package com.ankush.aivideostudio

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PresenterEngineActivity : AppCompatActivity() {
    private val gold = Color.rgb(218,178,58)
    private val white = Color.rgb(245,244,240)
    private val muted = Color.rgb(174,174,174)

    private var projectId = ""
    private var project: SavedProject? = null
    private var selectedEngine = "Local Planning / Adapter Preview"
    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var isRecording = false
    private lateinit var root: LinearLayout
    private lateinit var recordButton: Button
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectId = intent.getStringExtra("projectId") ?: ""
        project = ProjectStore.find(this, projectId)
        build()
    }

    private fun build() {
        val p = project
        val scroll = ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5,5,5), Color.rgb(18,15,10), Color.rgb(4,4,4))
            )
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "‹  वापस PRESENTER"
            textSize = 13f
            setTextColor(gold)
            setOnClickListener { finish() }
        }, lp(0,0,0,12))

        root.addView(TextView(this).apply {
            text = "REAL PRESENTER ENGINE"
            textSize = 25f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, lp(0,0,0,4))

        root.addView(TextView(this).apply {
            text = "Master photo → voice → expression plan → AI engine request"
            textSize = 12.5f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }, lp(0,0,0,16))

        root.addView(infoCard("PROJECT", p?.headline?.ifBlank { "Untitled Project" } ?: "Project not found"))
        root.addView(infoCard("PRESENTER", p?.presenterType ?: "Not selected"))
        root.addView(infoCard("MASTER PHOTO", if (p?.presenterImage.isNullOrBlank()) "⚠ Photo अभी चयनित नहीं" else "✓ Master presenter photo ready"))
        root.addView(infoCard("VOICE PROFILE", p?.voiceProfile ?: "Natural Hindi Female"))
        root.addView(infoCard("FORMAT", p?.format ?: "16:9"))

        root.addView(label("MASTER PRESENTER PREVIEW"))
        val image = ImageView(this).apply {
            minimumHeight = dp(220)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = fieldBackground()
            val uri = p?.presenterImage?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
            if (uri != null) setImageURI(uri)
        }
        root.addView(image, lp(0,0,0,14))

        root.addView(label("AI ENGINE ADAPTER"))
        val engineChoice = choice(selectedEngine)
        engineChoice.setOnClickListener {
            choose(
                listOf(
                    "Local Planning / Adapter Preview",
                    "SadTalker Adapter (planned)",
                    "Remote AI API Adapter (planned)",
                    "Custom Provider Adapter"
                )
            ) {
                selectedEngine = it
                engineChoice.text = it
                statusText.text = "Engine: $it"
            }
        }
        root.addView(engineChoice, lp(0,0,0,12))

        root.addView(label("NARRATION AUDIO"))
        root.addView(infoCard("AUDIO", if (p?.narrationAudio.isNullOrBlank()) "अभी recorded audio नहीं है" else "✓ Audio attached"))
        recordButton = actionButton("🎙  START VOICE RECORDING") { toggleRecording() }
        root.addView(recordButton, lp(0,0,0,8))
        root.addView(actionButton("🎧  IMPORT AUDIO FILE") { pickAudio() }, lp(0,0,0,12))

        root.addView(label("PIPELINE CHECK"))
        root.addView(checkCard("✓", "Master presenter identity", !p?.presenterImage.isNullOrBlank()))
        root.addView(checkCard("✓", "Full narration script", !p?.script.isNullOrBlank()))
        root.addView(checkCard("✓", "Voice profile", !p?.voiceProfile.isNullOrBlank()))
        root.addView(checkCard("✓", "Story-aware expression plan", !p?.expressionPlan.isNullOrBlank()))
        root.addView(checkCard("✓", "Output format", !p?.format.isNullOrBlank()))
        root.addView(checkCard("•", "AI facial animation engine", false, "Provider adapter अभी connect होना बाकी है"))

        statusText = TextView(this).apply {
            text = "Engine: $selectedEngine"
            textSize = 11f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        root.addView(statusText)

        root.addView(actionButton("🎭  GENERATE / REFRESH EXPRESSION TIMELINE") {
            val current = ProjectStore.find(this, projectId)
            if (current == null) {
                toast("पहले Presenter Project सेव करें")
            } else {
                val plan = if (current.expressionPlan.isNotBlank()) current.expressionPlan
                else "Neutral + attentive + natural blink • script-based expression mapping"
                ProjectStore.save(this, current.copy(expressionPlan = plan, generationStatus = "Expression timeline ready • Engine adapter pending"))
                project = ProjectStore.find(this, projectId)
                toast("Expression timeline तैयार है")
                build()
            }
        }, lp(0,0,0,8))

        root.addView(actionButton("📦  BUILD AI PRESENTER REQUEST PACKAGE") {
            buildRequestPackage()
        }, lp(0,0,0,8))

        root.addView(actionButton("▶  LOCAL PRESENTER PREVIEW") {
            showLocalPreview()
        }, lp(0,0,0,8))

        root.addView(TextView(this).apply {
            text = "महत्वपूर्ण: यह version AI model को phone में embed नहीं करता। यह provider-neutral request package और local recording तैयार करता है, ताकि बाद में free/open-source या paid engine adapter जोड़ा जा सके।"
            textSize = 10.5f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), 0)
        })
        setContentView(scroll)
    }

    private fun toggleRecording() {
        if (isRecording) stopRecording() else startRecording()
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 700)
            return
        }
        try {
            val dir = File(filesDir, "recordings")
            if (!dir.exists()) dir.mkdirs()
            recordingFile = File(dir, "narration_${System.currentTimeMillis()}.m4a")
            recorder = MediaRecorder(this).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(128000)
                setOutputFile(recordingFile!!.absolutePath)
                prepare()
                start()
            }
            isRecording = true
            recordButton.text = "⏹  STOP VOICE RECORDING"
            statusText.text = "Recording narration…"
        } catch (e: Exception) {
            recorder?.release()
            recorder = null
            recordingFile = null
            isRecording = false
            toast("Recording शुरू नहीं हो सकी: ${e.message ?: "unknown error"}")
        }
    }

    private fun stopRecording() {
        try {
            recorder?.stop()
        } catch (_: Exception) {}
        recorder?.release()
        recorder = null
        isRecording = false
        val path = recordingFile?.absolutePath ?: ""
        if (path.isNotBlank()) {
            val current = ProjectStore.find(this, projectId)
            if (current != null) {
                ProjectStore.save(this, current.copy(
                    narrationAudio = path,
                    generationStatus = "Narration audio ready • Engine adapter pending"
                ))
                project = ProjectStore.find(this, projectId)
            }
        }
        recordButton.text = "🎙  START VOICE RECORDING"
        statusText.text = "Narration audio saved locally"
        toast("Voice recording सेव हो गई")
    }

    private fun pickAudio() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "audio/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }, 703
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 703 || resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        val current = ProjectStore.find(this, projectId)
        if (current != null) {
            ProjectStore.save(this, current.copy(
                narrationAudio = uri.toString(),
                generationStatus = "Imported narration audio ready • Engine adapter pending"
            ))
            project = ProjectStore.find(this, projectId)
        }
        toast("Audio project में जोड़ दिया गया")
        build()
    }

    private fun buildRequestPackage() {
        val p = ProjectStore.find(this, projectId)
        if (p == null) {
            toast("Project नहीं मिला")
            return
        }
        if (p.presenterImage.isBlank()) {
            toast("पहले Master Presenter Photo चुनें")
            return
        }
        if (p.script.isBlank()) {
            toast("पहले पूरा news script डालें")
            return
        }
        val obj = JSONObject()
        obj.put("app", "Ankush AI Video Studio")
        obj.put("pipeline", "Real Presenter Engine")
        obj.put("projectId", p.id)
        obj.put("studio", p.studioName)
        obj.put("presenterType", p.presenterType)
        obj.put("presenterImage", p.presenterImage)
        obj.put("voiceProfile", p.voiceProfile)
        obj.put("narrationAudio", p.narrationAudio)
        obj.put("script", p.script)
        obj.put("headline", p.headline)
        obj.put("durationMinutes", p.duration)
        obj.put("format", p.format)
        obj.put("storyTone", p.storyTone)
        obj.put("expressionMode", p.expressionMode)
        obj.put("expressionPlan", p.expressionPlan)
        obj.put("engineAdapter", selectedEngine)
        obj.put("createdAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date()))

        val file = File(filesDir, "presenter_request_${p.id}.json")
        file.writeText(obj.toString(2))
        ProjectStore.save(this, p.copy(generationStatus = "AI request package ready • $selectedEngine"))
        project = ProjectStore.find(this, projectId)

        AlertDialog.Builder(this)
            .setTitle("AI Presenter Request तैयार")
            .setMessage("Request package फोन में तैयार है.\n\nEngine: $selectedEngine\nFile: ${file.name}\n\nयह package बाद में selected AI provider adapter को भेजा जा सकता है।")
            .setPositiveButton("ठीक है", null)
            .show()
    }

    private fun showLocalPreview() {
        val p = ProjectStore.find(this, projectId)
        if (p == null) return
        val msg = """
Presenter: ${p.presenterType}
Format: ${p.format}
Duration: ${p.duration} मिनट
Voice: ${p.voiceProfile}

Expression:
${if (p.expressionPlan.isBlank()) "अभी expression plan नहीं बना है।" else p.expressionPlan.take(1400)}

Status:
${p.generationStatus}

यह local preview केवल production plan दिखाता है। Final face animation के लिए AI Engine Adapter आवश्यक है।
        """.trimIndent()
        AlertDialog.Builder(this).setTitle("Presenter Preview").setMessage(msg).setPositiveButton("ठीक है", null).show()
    }

    private fun checkCard(icon: String, title: String, ready: Boolean, note: String = "") =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = fieldBackground()
            addView(TextView(this@PresenterEngineActivity).apply {
                text = if (ready) "✓" else icon
                textSize = 15f
                setTextColor(if (ready) gold else muted)
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(32), dp(42)))
            addView(TextView(this@PresenterEngineActivity).apply {
                text = if (note.isBlank()) title else "$title\n$note"
                textSize = 12.5f
                setTextColor(if (ready) white else muted)
                gravity = Gravity.CENTER_VERTICAL
            }, LinearLayout.LayoutParams(0, dp(42), 1f))
        }.apply { layoutParams = lp(0,0,0,6) }

    private fun infoCard(title: String, value: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(11), dp(14), dp(11))
        background = fieldBackground()
        addView(TextView(this@PresenterEngineActivity).apply {
            text = title
            textSize = 9.5f
            setTextColor(gold)
        })
        addView(TextView(this@PresenterEngineActivity).apply {
            text = value
            textSize = 13f
            setTextColor(white)
            setPadding(0, dp(4), 0, 0)
        })
        layoutParams = lp(0,0,0,7)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(gold)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(7))
    }

    private fun choice(current: String) = TextView(this).apply {
        text = current
        textSize = 14f
        setTextColor(white)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), 0, dp(14), 0)
        background = fieldBackground()
        minimumHeight = dp(50)
    }

    private fun choose(options: List<String>, result: (String) -> Unit) {
        AlertDialog.Builder(this).setTitle("Engine चुनें")
            .setItems(options.toTypedArray()) { _, which -> result(options[which]) }
            .show()
    }

    private fun actionButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 13f
        isAllCaps = false
        setTextColor(white)
        typeface = Typeface.DEFAULT_BOLD
        background = buttonBackground()
        minimumHeight = dp(50)
        setOnClickListener { click() }
    }

    private fun buttonBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(39,34,23), Color.rgb(20,20,20))
    ).apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), gold) }

    private fun fieldBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(22,22,22), Color.rgb(14,14,14))
    ).apply { cornerRadius = dp(13).toFloat(); setStroke(dp(1), Color.rgb(64,58,42)) }

    private fun lp(l:Int,t:Int,r:Int,b:Int) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(l),dp(t),dp(r),dp(b))
        }

    private fun dp(v:Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s:String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        if (isRecording) {
            try { recorder?.stop() } catch (_: Exception) {}
            recorder?.release()
            recorder = null
        }
        super.onDestroy()
    }
}

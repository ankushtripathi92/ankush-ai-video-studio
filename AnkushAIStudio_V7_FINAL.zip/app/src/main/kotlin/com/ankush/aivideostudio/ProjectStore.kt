package com.ankush.aivideostudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ProjectRecord(
    val id: String,
    var name: String,
    var studioIndex: Int,
    var studioName: String,
    var headline: String = "",
    var duration: String = "5",
    var script: String = "",
    var sceneNotes: String = "",
    var format: String = "16:9",
    var style: String = "",
    var mediaNames: MutableList<String> = mutableListOf(),
    var updatedAt: Long = System.currentTimeMillis()
)

object ProjectStore {
    private const val PREFS = "ankush_ai_projects_v7"
    private const val KEY = "projects"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun all(context: Context): MutableList<ProjectRecord> {
        val raw = prefs(context).getString(KEY, "[]") ?: "[]"
        val array = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val result = mutableListOf<ProjectRecord>()
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val media = mutableListOf<String>()
            val mediaArray = o.optJSONArray("media")
            if (mediaArray != null) for (j in 0 until mediaArray.length()) media.add(mediaArray.optString(j))
            result.add(
                ProjectRecord(
                    id = o.optString("id"),
                    name = o.optString("name", "Untitled Project"),
                    studioIndex = o.optInt("studioIndex", 0),
                    studioName = o.optString("studioName", "STUDIO"),
                    headline = o.optString("headline"),
                    duration = o.optString("duration", "5"),
                    script = o.optString("script"),
                    sceneNotes = o.optString("sceneNotes"),
                    format = o.optString("format", "16:9"),
                    style = o.optString("style"),
                    mediaNames = media,
                    updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
                )
            )
        }
        return result
    }

    fun get(context: Context, id: String): ProjectRecord? = all(context).firstOrNull { it.id == id }

    fun upsert(context: Context, project: ProjectRecord) {
        project.updatedAt = System.currentTimeMillis()
        val list = all(context)
        val index = list.indexOfFirst { it.id == project.id }
        if (index >= 0) list[index] = project else list.add(0, project)
        write(context, list)
    }

    fun create(context: Context, studioIndex: Int, studioName: String, name: String): ProjectRecord {
        val project = ProjectRecord(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { "Untitled $studioName" },
            studioIndex = studioIndex,
            studioName = studioName
        )
        upsert(context, project)
        return project
    }

    fun delete(context: Context, id: String) {
        write(context, all(context).filterNot { it.id == id }.toMutableList())
    }

    fun duplicate(context: Context, id: String): ProjectRecord? {
        val original = get(context, id) ?: return null
        val copy = original.copy(id = UUID.randomUUID().toString(), name = "${original.name} — Copy", mediaNames = original.mediaNames.toMutableList())
        upsert(context, copy)
        return copy
    }

    fun formatDate(time: Long): String = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(time))

    private fun write(context: Context, list: List<ProjectRecord>) {
        val array = JSONArray()
        list.forEach { p ->
            val o = JSONObject()
                .put("id", p.id)
                .put("name", p.name)
                .put("studioIndex", p.studioIndex)
                .put("studioName", p.studioName)
                .put("headline", p.headline)
                .put("duration", p.duration)
                .put("script", p.script)
                .put("sceneNotes", p.sceneNotes)
                .put("format", p.format)
                .put("style", p.style)
                .put("updatedAt", p.updatedAt)
            val media = JSONArray()
            p.mediaNames.forEach { media.put(it) }
            o.put("media", media)
            array.put(o)
        }
        prefs(context).edit().putString(KEY, array.toString()).apply()
    }
}

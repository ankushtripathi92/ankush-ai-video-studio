package com.ankush.aivideostudio

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ProjectsActivity : AppCompatActivity() {
    private val gold=Color.rgb(218,178,58)
    private val white=Color.rgb(245,244,240)
    private val muted=Color.rgb(174,174,174)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?){super.onCreate(savedInstanceState);showProjects()}
    override fun onResume(){super.onResume(); if(::root.isInitialized) showProjects()}

    private fun showProjects(){
        val scroll=ScrollView(this).apply{
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(5,5,5),Color.rgb(18,15,10),Color.rgb(4,4,4)))
            isFillViewport=true
        }
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(20),dp(18),dp(28))}
        scroll.addView(root)
        root.addView(TextView(this).apply{text="‹  वापस HOME";textSize=13f;setTextColor(gold);setPadding(0,0,0,dp(12));setOnClickListener{finish()}})
        root.addView(TextView(this).apply{text="MY PROJECTS";textSize=26f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER},lp(0,0,0,4))
        root.addView(TextView(this).apply{text="आपके सभी studios के saved projects यहाँ सुरक्षित रहेंगे";textSize=12.5f;setTextColor(muted);gravity=Gravity.CENTER},lp(0,0,0,18))

        val projects=ProjectStore.all(this).sortedByDescending{it.updatedAt}
        if(projects.isEmpty()){
            root.addView(info("अभी कोई saved project नहीं है","Studio में काम शुरू करें। Auto-save और manual Save दोनों उपलब्ध हैं."),lp(0,0,0,12))
        } else {
            projects.forEach { p -> root.addView(projectCard(p),lp(0,0,0,10)) }
        }
        root.addView(button("＋  NEW PROJECT") { chooseStudio() },lp(0,0,0,10))
        root.addView(TextView(this).apply{text="✓ Auto-save local device पर • Internet या paid AI API की जरूरत नहीं";textSize=10.5f;setTextColor(gold);gravity=Gravity.CENTER;setPadding(0,dp(12),0,0)})
        setContentView(scroll)
    }

    private fun projectCard(p:ProjectRecord)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(13),dp(15),dp(13));background=cardBg()
        addView(TextView(this@ProjectsActivity).apply{text=p.name;textSize=17f;setTextColor(white);typeface=Typeface.DEFAULT_BOLD})
        addView(TextView(this@ProjectsActivity).apply{text="${p.studioName}  •  ${p.duration} मिनट  •  ${p.format}";textSize=11.5f;setTextColor(gold);setPadding(0,dp(5),0,0)})
        addView(TextView(this@ProjectsActivity).apply{text="Last saved: ${ProjectStore.formatDate(p.updatedAt)}";textSize=10.5f;setTextColor(muted);setPadding(0,dp(4),0,dp(9))})
        val row=LinearLayout(this@ProjectsActivity).apply{orientation=LinearLayout.HORIZONTAL}
        row.addView(button("OPEN / EDIT"){open(p)},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(button("DUPLICATE"){ProjectStore.duplicate(this@ProjectsActivity,p.id);showProjects()},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(5),0,dp(5),0)})
        row.addView(button("DELETE"){confirmDelete(p)},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(5),0,0,0)})
        addView(row)
    }

    private fun open(p:ProjectRecord){
        val intent=when(p.studioIndex){
            4->Intent(this,ExplainerActivity::class.java)
            5->Intent(this,HorrorActivity::class.java)
            else->Intent(this,StudioActivity::class.java)
        }.apply{putExtra("projectId",p.id);putExtra("studioIndex",p.studioIndex);putExtra("studioName",p.studioName)}
        startActivity(intent)
    }
    private fun chooseStudio(){
        val names=arrayOf("चित्रकूट न्यूज़","वैदिक एवं तांत्रिक ज्ञान","Buycryptohub","Comedy Conversation","Editorial Explainer","Horror Story Studio")
        AlertDialog.Builder(this).setTitle("नया Project किस Studio में?").setItems(names){_,which->
            val intent=when(which){4->Intent(this,ExplainerActivity::class.java);5->Intent(this,HorrorActivity::class.java);else->Intent(this,StudioActivity::class.java)}
            intent.putExtra("studioIndex",which).putExtra("studioName",names[which]).putExtra("newProject",true)
            startActivity(intent)
        }.show()
    }
    private fun confirmDelete(p:ProjectRecord){AlertDialog.Builder(this).setTitle("Project delete करें?").setMessage("${p.name}\nयह action वापस नहीं होगा.").setNegativeButton("रद्द करें",null).setPositiveButton("DELETE"){_,_->ProjectStore.delete(this,p.id);showProjects()}.show()}
    private fun info(t:String,v:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(14),dp(15),dp(14));background=fieldBg();addView(TextView(this@ProjectsActivity).apply{text=t;textSize=15f;setTextColor(white);typeface=Typeface.DEFAULT_BOLD});addView(TextView(this@ProjectsActivity).apply{text=v;textSize=11.5f;setTextColor(muted);setPadding(0,dp(5),0,0)})}
    private fun button(t:String,click:()->Unit)=Button(this).apply{text=t;textSize=11f;isAllCaps=false;setTextColor(white);typeface=Typeface.DEFAULT_BOLD;background=buttonBg();minimumHeight=dp(46);setOnClickListener{click()}}
    private fun cardBg()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(25,23,19),Color.rgb(13,13,13))).apply{cornerRadius=dp(18).toFloat();setStroke(dp(1),Color.rgb(106,85,34))}
    private fun buttonBg()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(39,34,23),Color.rgb(20,20,20))).apply{cornerRadius=dp(12).toFloat();setStroke(dp(1),gold)}
    private fun fieldBg()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(22,22,22),Color.rgb(14,14,14))).apply{cornerRadius=dp(13).toFloat();setStroke(dp(1),Color.rgb(64,58,42))}
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(l),dp(t),dp(r),dp(b))}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}

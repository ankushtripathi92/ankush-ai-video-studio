package com.ankush.aivideostudio

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher

class ExplainerActivity : AppCompatActivity() {
    private val gold=Color.rgb(218,178,58); private val white=Color.rgb(245,244,240); private val muted=Color.rgb(174,174,174)
    private var projectId=""; private var projectName=""; private var headline=""; private var script=""; private var format="16:9"; private var style="Editorial Documentary"
    private var scriptField:EditText?=null; private var nameField:EditText?=null; private var status:TextView?=null; private var plan=mutableListOf<String>()

    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);projectId=intent.getStringExtra("projectId")?:"";load();showEditor()}
    override fun onPause(){syncSave(false);super.onPause()}
    override fun onBackPressed(){syncSave(false);super.onBackPressed()}

    private fun showEditor(){
        val scroll=ScrollView(this).apply{background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(5,5,5),Color.rgb(18,15,10),Color.rgb(4,4,4)));isFillViewport=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(20),dp(18),dp(28))};scroll.addView(root)
        root.addView(TextView(this).apply{text="‹  वापस HOME";textSize=13f;setTextColor(gold);setPadding(0,0,0,dp(12));setOnClickListener{syncSave(false);finish()}})
        root.addView(TextView(this).apply{text="🎞  EDITORIAL EXPLAINER";textSize=25f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER},lp(0,0,0,4))
        root.addView(TextView(this).apply{text="Story  →  Scenes  →  Visuals  →  Motion  →  Final Video";textSize=12.5f;setTextColor(muted);gravity=Gravity.CENTER},lp(0,0,0,18))
        root.addView(label("PROJECT"))
        val name=edit("Project name",projectName,1);val body=edit("अपनी कहानी / स्क्रिप्ट यहाँ लिखें…",script,9);nameField=name;scriptField=body
        root.addView(name,lp(0,0,0,10));root.addView(body,lp(0,0,0,16))
        root.addView(label("VISUAL STYLE"));root.addView(choice(style,listOf("Editorial Documentary","Paper Collage","2D Illustrated","Historical Archive","Cinematic Story","Map + Timeline","Infographic")).apply{setOnClickListener{choose(listOf("Editorial Documentary","Paper Collage","2D Illustrated","Historical Archive","Cinematic Story","Map + Timeline","Infographic")){style=it;text=it;syncSave(false)}}},lp(0,0,0,12))
        root.addView(label("FORMAT"));root.addView(choice(format,listOf("16:9","9:16")).apply{setOnClickListener{choose(listOf("16:9","9:16")){format=it;text=it;syncSave(false)}}},lp(0,0,0,12))
        status=TextView(this).apply{text="✓ Auto-save ready";textSize=10.5f;setTextColor(gold);gravity=Gravity.CENTER;setPadding(0,0,0,dp(10))};root.addView(status)
        addWatcher(name);addWatcher(body)
        root.addView(button("🧩  BUILD AUTO SCENE PLAN"){syncSave(false);buildPlan(body.text.toString())});root.addView(button("👁  PREVIEW SCENE PLAN"){showPlanDialog()});root.addView(button("💾  SAVE PROJECT"){syncSave(true);toast("Project सेव हो गया")});root.addView(button("🚀  PREPARE FOR AI GENERATION"){syncSave(false);if(plan.isEmpty())buildPlan(body.text.toString(),false);AlertDialog.Builder(this).setTitle("AI Generation Ready").setMessage("Scene plan तैयार है: ${plan.size} scene(s)\nStyle: $style\nFormat: $format\n\nAI generation बाद में provider/API adapter से जोड़ी जाएगी.").setPositiveButton("ठीक है",null).show()})
        root.addView(TextView(this).apply{text="✓ Auto-save local device पर • कोई paid AI API स्वतः call नहीं होती";textSize=11f;setTextColor(muted);setPadding(dp(4),dp(14),dp(4),0)})
        setContentView(scroll)
    }
    private fun buildPlan(raw:String,show:Boolean=true){plan=raw.split(Regex("(?<=[.!?।])\\s+|\\n+")).map{it.trim()}.filter{it.isNotBlank()}.take(30).toMutableList();if(plan.isEmpty())plan=mutableListOf("Scene 1 — पहले अपनी story/script लिखें।");if(show)showPlanDialog()}
    private fun showPlanDialog(){val text=if(plan.isEmpty())"अभी scene plan नहीं बना है।" else plan.mapIndexed{i,s->"SCENE ${i+1}\n$s\nVisual: $style\nDuration: auto"}.joinToString("\n\n");AlertDialog.Builder(this).setTitle("Auto Scene Plan").setMessage(text).setPositiveButton("ठीक है",null).show()}
    private fun syncSave(show:Boolean){nameField?.let{projectName=it.text.toString()};scriptField?.let{script=it.text.toString()};if(projectName.isBlank()&&script.isBlank())return;if(projectName.isBlank())projectName="Editorial Explainer Project";if(projectId.isBlank())projectId=ProjectStore.create(this,4,"Editorial Explainer",projectName).id;ProjectStore.upsert(this,ProjectRecord(projectId,projectName,4,"Editorial Explainer",headline,"5",script,"",format,style,mutableListOf()));status?.text=if(show)"✓ Project saved successfully" else "✓ All changes saved"}
    private fun load(){val p=if(projectId.isBlank())null else ProjectStore.get(this,projectId);if(p!=null){projectName=p.name;headline=p.headline;script=p.script;format=p.format;if(p.style.isNotBlank())style=p.style}}
    private fun addWatcher(v:EditText){v.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){};override fun afterTextChanged(e:Editable?){syncSave(false)}})}
    private fun button(t:String,click:()->Unit)=Button(this).apply{text=t;textSize=13.5f;isAllCaps=false;setTextColor(white);typeface=Typeface.DEFAULT_BOLD;background=buttonBackground();minimumHeight=dp(50);setOnClickListener{click()}}
    private fun edit(h:String,v:String,l:Int)=EditText(this).apply{hint=h;setText(v);setTextColor(white);setHintTextColor(Color.rgb(120,120,120));textSize=14f;minLines=l;gravity=Gravity.TOP;background=fieldBackground();setPadding(dp(14),dp(12),dp(14),dp(12))}
    private fun label(t:String)=TextView(this).apply{text=t;textSize=11f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(4),0,dp(7))}
    private fun choice(cur:String,opts:List<String>)=TextView(this).apply{text=cur;textSize=14f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(14),0);background=fieldBackground();minimumHeight=dp(50);setOnClickListener{choose(opts){text=it}}}
    private fun choose(opts:List<String>,result:(String)->Unit){AlertDialog.Builder(this).setTitle("चयन करें").setItems(opts.toTypedArray()){_,i->result(opts[i])}.show()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun fieldBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(22,22,22),Color.rgb(14,14,14))).apply{cornerRadius=dp(13).toFloat();setStroke(dp(1),Color.rgb(64,58,42))}
    private fun buttonBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(39,34,23),Color.rgb(20,20,20))).apply{cornerRadius=dp(14).toFloat();setStroke(dp(1),gold)}
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(l),dp(t),dp(r),dp(b))}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}

package com.ankush.aivideostudio

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class StudioActivity : AppCompatActivity() {
    private val gold = Color.rgb(218,178,58)
    private val white = Color.rgb(245,244,240)
    private val muted = Color.rgb(174,174,174)
    private var studioIndex = 0
    private var studioName = "STUDIO"
    private var projectId = ""
    private var format = "16:9"
    private var duration = "5"
    private var headline = ""
    private var script = ""
    private var mediaNames = mutableListOf<String>()
    private var lastSavedAt = 0L
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        studioIndex = intent.getIntExtra("studioIndex", 0)
        studioName = intent.getStringExtra("studioName") ?: "STUDIO"
        projectId = intent.getStringExtra("projectId") ?: ""
        loadProject()
        showStudioMenu()
    }

    override fun onPause() {
        autoSave()
        super.onPause()
    }

    private fun loadProject() {
        if (projectId.isNotBlank()) {
            ProjectStore.find(this, projectId)?.let {
                headline = it.headline
                duration = it.duration
                script = it.script
                format = it.format
                mediaNames = it.mediaNames.toMutableList()
                lastSavedAt = it.updatedAt
                return
            }
        }
        format = "16:9"
        duration = "5"
        headline = ""
        script = ""
        mediaNames = mutableListOf()
    }

    private fun autoSave() {
        if (headline.isBlank() && script.isBlank() && mediaNames.isEmpty()) return
        projectId = ProjectStore.save(
            this,
            SavedProject(projectId, studioIndex, studioName, headline, duration, script, format, mediaNames, lastSavedAt)
        )
        lastSavedAt = System.currentTimeMillis()
    }

    private fun saveWithMessage(message: String) {
        autoSave()
        toast(if (projectId.isBlank()) "Project में अभी content भरें" else message)
    }

    private fun baseRoot(title: String, subtitle: String): ScrollView {
        val scroll = ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5,5,5), Color.rgb(18,15,10), Color.rgb(4,4,4))
            )
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18),dp(20),dp(18),dp(28))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "‹  वापस STUDIO"
            textSize = 13f
            setTextColor(gold)
            setPadding(0,0,0,dp(12))
            setOnClickListener { autoSave(); showStudioMenu() }
        })

        root.addView(TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, lp(0,0,0,4))

        root.addView(TextView(this).apply {
            text = subtitle
            textSize = 12.5f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }, lp(0,0,0,12))

        root.addView(TextView(this).apply {
            text = if (projectId.isBlank()) "●  नया project  •  Auto-save तैयार" else "✓  Project auto-save active"
            textSize = 10.5f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }, lp(0,0,0,14))
        return scroll
    }

    private fun showStudioMenu() {
        val scroll = baseRoot(studioName, "Professional Studio Workspace  •  project settings यहाँ से manage करें")

        root.addView(actionCard("📁  MY PROJECTS", "सभी saved projects खोलें, edit करें या manage करें") {
            autoSave()
            startActivity(Intent(this, ProjectsActivity::class.java))
        }, lp(0,0,0,10))

        val items = when(studioIndex) {
            0 -> listOf(
                "🎬  FULL NEWS PRESENTER" to "पूरी खबर को female/news anchor से प्रस्तुत करने की तैयारी",
                "🎙️  INTERVIEW / EXPERT MODE" to "Anchor + guest/expert interview workflow",
                "👤  ANCHOR / CHARACTER LIBRARY" to "Anchors, presenters और guest references manage करें",
                "🖼️  PHOTOS / VIDEOS / MEDIA" to "फोन से visuals चुनें; final creative edit manual रहेगा",
                "📝  SCRIPT / VOICE" to "News script और narration/voice profile तैयार करें",
                "📐  16:9 / 9:16" to "Video format चुनें",
                "▶  PREVIEW / GENERATE" to "Current project का summary और AI-ready status देखें"
            )
            1 -> listOf(
                "🎬  FULL PRESENTER" to "पूजा, ज्ञान और धार्मिक विषयों के लिए presenter setup",
                "🎙️  प्रश्न–उत्तर / PODCAST" to "प्रश्नकर्ता + अंकुश शास्त्री/guest बातचीत workflow",
                "👤  CHARACTER / PRESENTER LIBRARY" to "Presenter और guest references manage करें",
                "🖼️  PHOTOS / VIDEOS / MEDIA" to "पूजा, ग्रंथ, चित्र और अन्य media जोड़ें",
                "📝  SCRIPT / VOICE" to "आध्यात्मिक script और narration तैयार करें",
                "📐  16:9 / 9:16" to "Video format चुनें",
                "▶  PREVIEW / GENERATE" to "Project summary और AI-ready status देखें"
            )
            2 -> listOf(
                "📈  FULL PRESENTER" to "Stock/Crypto विषय पर professional presenter workflow",
                "🎙️  COMMENTARY / EXPERT MODE" to "Presenter + expert/guest commentary",
                "👤  PRESENTER / CHARACTER LIBRARY" to "अपना presenter/voice profile manage करें",
                "🖼️  PHOTOS / VIDEOS / MEDIA" to "BSE/NSE/company screenshots आप स्वयं चुनें",
                "📝  SCRIPT / VOICE" to "Market/crypto narration और voice profile",
                "📐  16:9 / 9:16" to "Video format चुनें",
                "▶  PREVIEW / GENERATE" to "Project summary देखें"
            )
            else -> listOf(
                "🎬  CHARACTER 1 / QUESTIONER" to "पहला comedy character और dialogue setup",
                "🎙️  CHARACTER 2 / ANSWERER" to "दूसरा character और dialogue setup",
                "👤  CHARACTER LIBRARY" to "Character reference images manage करें",
                "🖼️  PHOTOS / VIDEOS / MEDIA" to "Generated character images/media जोड़ें",
                "📝  SCRIPT / DIALOGUE" to "Dialogue sequence और voice notes तैयार करें",
                "📐  16:9 / 9:16" to "Video format चुनें",
                "▶  PREVIEW / GENERATE" to "Dialogue project summary देखें"
            )
        }

        items.forEachIndexed { index, pair ->
            root.addView(actionCard(pair.first, pair.second) {
                when(index) {
                    0 -> showPresenter()
                    1 -> showInterview()
                    2 -> showLibrary()
                    3 -> showMedia()
                    4 -> showScriptVoice()
                    5 -> showFormat()
                    6 -> showPreview()
                }
            }, lp(0,0,0,10))
        }

        root.addView(TextView(this).apply {
            text = "✓ Auto-save active  •  Back/phone interruption के बाद project सुरक्षित रहेगा"
            textSize = 10.5f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0,dp(12),0,0)
        })
        setContentView(scroll)
    }

    private fun showPresenter() {
        val scroll = baseRoot("Presenter Setup", "Script + presenter + voice + format को एक project में रखें")
        val headlineField = edit("Headline / Topic", headline, 1)
        val durationField = edit("Duration (minutes)", duration, 1)
        val sceneField = edit("Scene / visual notes", script, 3)
        root.addView(label("PROJECT DETAILS"))
        root.addView(headlineField, lp(0,0,0,10))
        root.addView(durationField, lp(0,0,0,10))
        root.addView(sceneField, lp(0,0,0,14))

        root.addView(label("VIDEO FORMAT"))
        root.addView(choice(format, listOf("16:9","9:16")).apply {
            setOnClickListener {
                choose(listOf("16:9","9:16")) { selected ->
                    format = selected
                    text = "FORMAT  •  $selected"
                    autoSave()
                }
            }
        }, lp(0,0,0,14))

        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                headline = headlineField.text.toString()
                duration = durationField.text.toString()
                script = sceneField.text.toString()
                autoSave()
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        headlineField.addTextChangedListener(watcher)
        durationField.addTextChangedListener(watcher)
        sceneField.addTextChangedListener(watcher)

        root.addView(actionButton("💾  SAVE PRESENTER PROJECT") {
            headline = headlineField.text.toString()
            duration = durationField.text.toString()
            script = sceneField.text.toString()
            saveWithMessage("Presenter project सेव हो गया")
        })
        root.addView(actionButton("▶  PREVIEW PROJECT", lp(0,0,0,8)) { autoSave(); showPreview() })
        root.addView(TextView(this).apply {
            text = "✓ हर बदलाव Auto-save होता है"
            textSize = 10.5f; setTextColor(gold); gravity = Gravity.CENTER
        })
        setContentView(scroll)
    }

    private fun showInterview() {
        val scroll = baseRoot("Interview / Expert Mode", "Anchor questions + guest answers के लिए structured project")
        val topic = edit("Interview topic", headline, 2)
        val questions = edit("Questions / talking points", script, 8)
        val guest = edit("Guest / Expert name", "", 1)
        root.addView(label("INTERVIEW SETUP"))
        root.addView(topic,lp(0,0,0,10))
        root.addView(guest,lp(0,0,0,10))
        root.addView(questions,lp(0,0,0,14))
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                headline=topic.text.toString(); script=questions.text.toString(); autoSave()
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        topic.addTextChangedListener(watcher); questions.addTextChangedListener(watcher)
        root.addView(actionButton("💾  SAVE INTERVIEW PROJECT") { headline=topic.text.toString(); script=questions.text.toString(); saveWithMessage("Interview project सेव हो गया") })
        root.addView(actionButton("👁  PREVIEW INTERVIEW PLAN") { autoSave(); dialog("Interview Plan","Topic: ${topic.text}\nGuest: ${guest.text}\nQuestions: ${questions.text.take(600)}") })
        setContentView(scroll)
    }

    private fun showLibrary() {
        val scroll = baseRoot("Anchor / Character Library", "Reference images और role profiles का local foundation")
        root.addView(infoCard("आर्या — Female News Anchor","Natural Hindi Female • News Presenter • 16:9"))
        root.addView(infoCard("अंकुश शास्त्री — Presenter","User reference • Spiritual / Finance / Interview"))
        root.addView(infoCard("Guest / Expert — Custom","अपनी image बाद में media picker से जोड़ें"))
        root.addView(actionButton("＋  ADD REFERENCE IMAGE") { pickMedia(true) })
        root.addView(actionButton("✓  USE SELECTED PROFILE") { toast("Selected profile workflow के लिए तैयार है") })
        setContentView(scroll)
    }

    private fun showMedia() {
        val scroll = baseRoot("Photos / Videos / Media", "Visuals आप स्वयं चुनें — automatic screenshot selection नहीं")
        root.addView(TextView(this).apply {
            text = if(mediaNames.isEmpty()) "अभी कोई media नहीं चुना गया।" else mediaNames.joinToString("\n") { "• $it" }
            textSize=13f; setTextColor(white); setPadding(dp(14),dp(14),dp(14),dp(14)); background=fieldBackground()
        }, lp(0,0,0,14))
        root.addView(actionButton("＋  SELECT PHOTOS / VIDEOS") { pickMedia(false) })
        root.addView(actionButton("🗑  CLEAR MEDIA LIST") { mediaNames.clear(); autoSave(); showMedia() })
        setContentView(scroll)
    }

    private fun showScriptVoice() {
        val scroll = baseRoot("Script / Voice", "Script, recorded narration और voice profile को project में रखें")
        val scriptField = edit("Full script / narration", script, 10)
        root.addView(label("SCRIPT"))
        root.addView(scriptField,lp(0,0,0,14))
        root.addView(label("VOICE PROFILE"))
        root.addView(choice("Natural Hindi Female", listOf("Natural Hindi Female","Natural Hindi Male","User Recorded Voice","AI Voice Clone — later adapter")))
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                script=scriptField.text.toString(); autoSave()
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        scriptField.addTextChangedListener(watcher)
        root.addView(actionButton("💾  SAVE SCRIPT / VOICE SETTINGS") { script=scriptField.text.toString(); saveWithMessage("Script और voice settings सेव हो गईं") })
        root.addView(actionButton("🎙  SELECT RECORDED AUDIO") { pickAudio() })
        setContentView(scroll)
    }

    private fun showFormat() {
        val scroll = baseRoot("Video Format", "Output orientation चुनें")
        root.addView(label("VIDEO FORMAT"))
        root.addView(choice(format, listOf("16:9","9:16")).apply {
            setOnClickListener { choose(listOf("16:9","9:16")) { format=it; autoSave(); showFormat() } }
        },lp(0,0,0,14))
        root.addView(infoCard("16:9","YouTube / documentary / TV-style presentation"))
        root.addView(infoCard("9:16","Shorts / Reels / vertical social video"))
        root.addView(actionButton("💾  SAVE FORMAT") { saveWithMessage("Format $format सेव हो गया") })
        setContentView(scroll)
    }

    private fun showPreview() {
        val scroll = baseRoot("Project Preview", "AI generation से पहले current project की जाँच")
        root.addView(infoCard("Studio", studioName))
        root.addView(infoCard("Headline / Topic", if(headline.isBlank()) "अभी नहीं भरा गया" else headline))
        root.addView(infoCard("Duration", "$duration मिनट"))
        root.addView(infoCard("Format", format))
        root.addView(infoCard("Media", "${mediaNames.size} file(s)"))
        root.addView(infoCard("SCRIPT / NOTES", if(script.isBlank()) "अभी नहीं" else "${script.take(180)}${if(script.length>180)"…" else ""}"))
        root.addView(actionButton("💾  SAVE PROJECT") { saveWithMessage("Project सेव हो गया") })
        root.addView(actionButton("🚀  PREPARE FOR AI GENERATION") {
            autoSave()
            dialog("AI Generation Ready","Project foundation तैयार है.\n\nAI voice, avatar, lip-sync और final rendering बाद में provider/API adapter से जोड़े जाएंगे.\n\nअभी कोई paid API call नहीं हुई।")
        })
        setContentView(scroll)
    }

    private fun actionCard(title:String, subtitle:String, click:()->Unit)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        setPadding(dp(16),dp(13),dp(16),dp(13))
        background=cardBackground()
        isClickable=true
        setOnClickListener{click()}
        addView(TextView(this@StudioActivity).apply{
            text=title; textSize=16f; setTextColor(white); typeface=Typeface.DEFAULT_BOLD
        })
        addView(TextView(this@StudioActivity).apply{
            text=subtitle; textSize=11.5f; setTextColor(muted); setPadding(0,dp(5),0,0)
        })
        addView(TextView(this@StudioActivity).apply{
            text="खोलें  →"; textSize=10.5f; setTextColor(gold); typeface=Typeface.DEFAULT_BOLD
            gravity=Gravity.RIGHT; setPadding(0,dp(7),0,0)
        })
    }

    private fun actionButton(text:String, params: LinearLayout.LayoutParams = lp(0,0,0,10), click:()->Unit)=Button(this).apply{
        this.text=text; textSize=13.5f; isAllCaps=false; setTextColor(white); typeface=Typeface.DEFAULT_BOLD
        background=buttonBackground(); setOnClickListener{click()}; minimumHeight=dp(48); layoutParams=params
    }

    private fun infoCard(title:String, value:String)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12)); background=fieldBackground()
        addView(TextView(this@StudioActivity).apply{text=title.uppercase();textSize=9.5f;setTextColor(gold)})
        addView(TextView(this@StudioActivity).apply{text=value;textSize=13f;setTextColor(white);setPadding(0,dp(5),0,0)})
        layoutParams=lp(0,0,0,8)
    }

    private fun edit(hint:String,value:String,lines:Int)=EditText(this).apply{
        setHint(hint); setText(value); setTextColor(white); setHintTextColor(Color.rgb(120,120,120))
        textSize=14f; minLines=lines; gravity=Gravity.TOP; background=fieldBackground(); setPadding(dp(14),dp(12),dp(14),dp(12))
    }

    private fun label(text:String)=TextView(this).apply{this.text=text;textSize=11f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(3),0,dp(7))}

    private fun choice(current:String,options:List<String>)=TextView(this).apply{
        text=current;textSize=14f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(14),0)
        background=fieldBackground(); minimumHeight=dp(50)
        setOnClickListener{choose(options){selected->text=selected}}
    }

    private fun choose(options:List<String>, result:(String)->Unit){
        AlertDialog.Builder(this).setTitle("चयन करें").setItems(options.toTypedArray()){_,which->result(options[which])}.show()
    }

    private fun pickMedia(single:Boolean){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            type="*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE,!single); addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, if(single)101 else 102)
    }
    private fun pickAudio(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="audio/*";addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(i,103)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK||data==null)return
        val uris=mutableListOf<Uri>()
        data.data?.let{uris.add(it)}
        data.clipData?.let{clip->for(i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)}
        if(requestCode==101 || requestCode==102){
            uris.forEach{mediaNames.add(it.lastPathSegment ?: "selected media")}
            autoSave(); showMedia()
        } else if(requestCode==103){
            toast("Recorded audio selected")
        }
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun dialog(title:String,message:String)=AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("ठीक है",null).show()
    private fun cardBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(25,23,19),Color.rgb(13,13,13))).apply{cornerRadius=dp(18).toFloat();setStroke(dp(1),Color.rgb(106,85,34))}
    private fun buttonBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(39,34,23),Color.rgb(20,20,20))).apply{cornerRadius=dp(14).toFloat();setStroke(dp(1),gold)}
    private fun fieldBackground()=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(22,22,22),Color.rgb(14,14,14))).apply{cornerRadius=dp(13).toFloat();setStroke(dp(1),Color.rgb(64,58,42))}
    private fun lp(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(l),dp(t),dp(r),dp(b))}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}

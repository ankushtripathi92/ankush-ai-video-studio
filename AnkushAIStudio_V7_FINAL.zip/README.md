# Ankush AI Video Studio V7

V7 is a functional project-management upgrade over V6.

## V7 additions
- My Projects library shared across all 6 studios
- Local persistent project storage using SharedPreferences/JSON
- Auto-save while editing and when the app goes to background/back
- Manual Save Project button
- Project name, studio, duration, format and last-saved time
- Open/Edit, Duplicate and Delete from My Projects
- Presenter Setup now includes a clear 16:9 / 9:16 selector
- Project Preview shows the saved format and auto-save status
- Editorial Explainer and Horror Story Studio also save/load projects
- No paid AI API is called automatically

## Build
Use the repository GitHub Actions workflow with Java 17, Android SDK 35 and Gradle 8.9.
The archive filename for this release is `AnkushAIStudio_V7_FINAL.zip`.

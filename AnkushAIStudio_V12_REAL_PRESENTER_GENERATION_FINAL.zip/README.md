# Ankush AI Video Studio — V12 Real Presenter Generation

V12 continues the stable V11 Real Presenter Engine Bridge and adds the V12 presenter-generation workspace.

## Main new feature
The Chitrakoot News presenter workflow now has a dedicated **Real Presenter Engine Bridge**.

Pipeline:
Master Presenter Photo
→ Narration Audio
→ Story / Expression Plan
→ AI Engine Adapter Request
→ Future facial animation / lip-sync provider
→ Final presenter video

## V12 functions
- Master presenter photo preview
- Female AI News Anchor / My AI Avatar / Guest profile
- Local narration recording (M4A)
- Import existing narration audio
- Engine adapter selection
- Story-aware expression timeline
- Presenter readiness checklist
- JSON AI Presenter Request Package
- Local production-plan preview
- ProjectStore persistence for narration audio

## Important limitation
The APK does not contain a large AI video model and does not call a paid provider by itself.
The engine bridge is provider-neutral so a suitable open-source/free or paid engine can be
connected later without rebuilding the whole app architecture.

## GitHub build
Workflow expects:
`AnkushAIStudio_V12_REAL_PRESENTER_GENERATION.zip`

The GitHub Actions workflow builds:
`app-debug.apk`


V12 REAL PRESENTER GENERATION FOUNDATION
- Master presenter photo, narration, expression planning, engine adapter selection, local motion concept preview, request-package generation and JSON export.
- Final AI facial animation is intentionally provider-neutral and must be connected through a licensed model/provider adapter.
